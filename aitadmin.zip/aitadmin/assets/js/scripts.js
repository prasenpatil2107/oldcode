$(document).ready(function(){
    $('#form_add').validate();
    //$("#textarea-wysiwyge").Editor();
    $( "#birthday" ).datepicker({
        'format':'yyyy-mm-dd'
    });

	    $( "#fromdate" ).datepicker({
        'format':'yyyy-mm-dd'
    });
 
	
	    $( "#todate" ).datepicker({
        'format':'yyyy-mm-dd'
    });

	
    //     var v = $('#form_add').validate({ 
    //     // exclude it from validation
    //     ignore: ":hidden:not(#textarea-wysiwyge),.note-editable.panel-body"
    // });
    $('#textarea-wysiwyge').summernote({

        focus: true,
        height: 200,

        callbacks:{
            onImageUpload: function(files, editor, welEditable) {

                sendFile(files[0], editor, welEditable);
            },
            // onChange: function(contents, $editable) {
            //       // Note that at this point, the value of the `textarea` is not the same as the one
            //      // you entered into the summernote editor, so you have to set it yourself to make
            //      // the validation consistent and in sync with the value.
            //      $('#textarea-wysiwyge').val($('#textarea-wysiwyge').summernote('isEmpty') ? "" : contents);

            //      // You should re-validate your element after change, because the plugin will have
            //      // no way to know that the value of your `textarea` has been changed if the change
            //     // was done programmatically.
            //    v.element($('#textarea-wysiwyge'));
            // }

        },


    });


//    var myElement = $('#summernote');

//    myElement.summernote({
//       // See: http://summernote.org/deep-dive/
//       callbacks: {
//          onChange: function(contents, $editable) {
//           // Note that at this point, the value of the `textarea` is not the same as the one
//          // you entered into the summernote editor, so you have to set it yourself to make
//          // the validation consistent and in sync with the value.
//          myElement.val(myElement.summernote('isEmpty') ? "" : contents);

//          // You should re-validate your element after change, because the plugin will have
//          // no way to know that the value of your `textarea` has been changed if the change
//         // was done programmatically.
//        v.element(myElement);
//     }
//   }
// });

//     $('#form_add').each(function () {
//     if ($(this).data('validator'))
//         $(this).data('validator').settings.ignore = ".note-editor *";
// });

    // $('#fileToUpload').change(function(e){
    //  var filename = $(this).val().replace(/.*(\/|\\)/, '');
    //  alert(filename);
    //  if (localStorage) {
    //    alert("LS is sp");
    //    // localStorage.setItem('name', filename);
    //    // fileDownload(filename)
    //    //  .done(function () { alert('File download a success!'); })
    //    //  .fail(function () { alert('File download failed!'); });
    //   } else {
    //     alert("LS is not sp");
    //   }
    //
    // })


});

function sendFile(file, editor, welEditable) {

    data = new FormData();
    data.append("files", file);
    $.ajax({
        data: data,
        type: "POST",
        url: site_url+"admin/main/descImguploads",
        cache: false,
        contentType: false,
        processData: false,
        success: function(url) {
            //editor.insertImage(welEditable, url);
            $('#textarea-wysiwyge').summernote('editor.insertImage', url);
        }
    });
}
$(function() {

    var oTable;

    function load() {

        oTable = $('#datatable_ajax').dataTable({
            "ajax": {"url": site_url+"admin/main/loadslides"},
            "processing": true,
            "serverSide": true,
            "bFilter": true,
            "bLengthChange": false,
            "columnDefs": [{
                    "targets": [4],
                    "orderable": false
                }],
            "drawCallback": function(settings) {
                var totalrec = settings.fnRecordsDisplay();
                $("#totalrec").html(totalrec);
                $('[data-toggle="tooltip"]').tooltip();

            }
        });
    }

    load();

    $("#filtersrch a").click(function() {

        var atbr = $(this).attr("p");
        $("#filtersrch a").removeClass('active');

        if(atbr == "all")
            oTable.fnFilter('');
        else
            oTable.fnFilter( atbr );

        $(this).addClass('active');
        $("#searchrefresh").show();

    });

    $("#searchitems").click(function() {

        var id = $("#catid").val();
        var title = $("#title").val();
        var posteddate = $("#posteddate").val();

      if(id!='' || title!='' || posteddate!='')
           var aryser = id+"{{-}}"+title+"{{-}}"+posteddate;
        else
            var aryser = '';
         oTable.fnFilter( aryser );
        $("#searchrefresh").show();
         $('#catid').val('');
         $("#title").val('');
         $('#posteddate').val('');

    });
    window.SearchOrgLoad = function()
{
    oTable.fnFilter('');
    $("#filtersrch a").removeClass('active');
    $("#filtersrch a:first-child").addClass('active');
    $("#searchrefresh").hide();
}


    setTimeout(function(){ jQuery("#suc_message").hide(); }, 3000);

});

function deleterecord(encodedata){
var target_row = $(this).closest("tr").get(0); // this line did the trick
if(confirm('Do you want to delete this record ?')){
        $.ajax
        ({
            type: "POST",
            url: site_url+'admin/main/ajaxdelete',
            data: "id=" + encodedata,
            success: function(msg)
            {
                var oTable = $('#datatable_ajax').DataTable();
                oTable.row(target_row).remove().draw( true );
                alert_message('success','Record is Deleted Sucessfully.');

            }
        });
}
}


function changestatus(status,itemid) {
$.ajax({
type: "post",
url: site_url+'admin/main/ajaxchangestatus',
data: "status=" + status + "&id=" + itemid,
success: function(msg) {
if(status == 2){
var asd = '<a class="btn btn-sm btn-default status-btn" title="Status - InActive" data-toggle="tooltip" data-original-title="Status - InActive" onclick="changestatus(1,' + itemid + ')"><i class="fa fa-star cold2"></i></a>';
document.getElementById("status-flag-" + itemid).innerHTML = asd;
alert_message('success','Status Changed Successfully.');
} else {
var asd = '<a class="btn btn-sm btn-success status-btn" title="Status - Active" data-toggle="tooltip" data-original-title="Status - Active" onclick="changestatus(2,' + itemid + ')"><i class="fa fa-star"></i></a>';
document.getElementById("status-flag-" + itemid).innerHTML = asd;
alert_message('success','Status Changed Successfully.');
}
}
});
}

function alert_message(type,message){
	$('#alert-message').removeClass('alert-success');
	$('#alert-message').removeClass('alert-danger');
	if(type == 'success'){
			$('#alert-message').addClass('alert-success');
	}else{
			$('#alert-message').addClass('alert-danger');
	}
	$('#alert-message').text(message);
	$('#alert-message-block').show();
	setTimeout(function(){ $("#alert-message-block").hide('slow'); }, 4000);
}
 $(function () 
 {
    $("#birthday_list").dataTable();
    $("#event_list").dataTable();

    var EventTable;

    function load() {

        EventTable = $('#datatable_ajax_events').dataTable({
            "ajax": {"url": site_url+"admin/main/loadevents"},
            "processing": true,
            "serverSide": true,
            "bFilter": true,
            "bLengthChange": false,
            "columnDefs": [{
                    "targets": [4],
                    "orderable": false
                }],
            "drawCallback": function(settings) {
                var totalrec = settings.fnRecordsDisplay();
                $("#totalrec").html(totalrec);
                $('[data-toggle="tooltip"]').tooltip();

            }
        });
    }

    load();





    
});

function change_event_status(status,itemid) {
    $.ajax({
        type: "post",
        url: site_url+'admin/main/change_event_status',
        data: "status=" + status + "&id=" + itemid,
        success: function(msg) {
            if(status == 2){
                var asd = '<a class="btn btn-sm btn-default status-btn" title="Status - InActive" data-toggle="tooltip" data-original-title="Status - InActive" onclick="changestatus(1,' + itemid + ')"><i class="fa fa-star cold2"></i></a>';
                document.getElementById("status-flag-" + itemid).innerHTML = asd;
                alert_message('success','Status Changed Successfully.');
            } else {
                var asd = '<a class="btn btn-sm btn-success status-btn" title="Status - Active" data-toggle="tooltip" data-original-title="Status - Active" onclick="changestatus(2,' + itemid + ')"><i class="fa fa-star"></i></a>';
                document.getElementById("status-flag-" + itemid).innerHTML = asd;
                alert_message('success','Status Changed Successfully.');
            }
        }
    });
}

   function bd_add1()
    {
        alert("kjdknfkgjf");
        $("#bdimage").change(function (e) {
    var file, img;
    if ((file = this.files[0])) {
        img = new Image();
        img.onload = function () {
            alert(this.width + " " + this.height);
        };
        img.src = _URL.createObjectURL(file);
    }
});

        
    //     var file, img;
    // if ((file = this.files[0])) {
    //     img = new Image();
    //     img.onload = function () {
    //         alert(this.width + " " + this.height);
    //     };
    //     return;
    //     // img.src = _URL.createObjectURL(file);
    // }
        // document.getElementById('form_add').submit();
    }

    function img_Uploadcheck() {
    //Get reference of FileUpload.
    var fileUpload = document.getElementById("bdimage");
 
    //Check whether the file is valid Image.
    var regex = new RegExp("([a-zA-Z0-9\s_\\.\-:])+(.jpg|.png|.gif|.jpeg)$");
    if (regex.test(fileUpload.value.toLowerCase())) {
 
        //Check whether HTML5 is supported.
        if (typeof (fileUpload.files) != "undefined") {
            //Initiate the FileReader object.
            var reader = new FileReader();
            //Read the contents of Image File.
            reader.readAsDataURL(fileUpload.files[0]);
            reader.onload = function (e) {
                //Initiate the JavaScript Image object.
                var image = new Image();
 
                //Set the Base64 string return from FileReader as source.
                image.src = e.target.result;
                       
                //Validate the File Height and Width.
                image.onload = function () {
                    var height = this.height;
                    var width = this.width;
                    if (height > 2000 || width > 2000) {
                        alert("Height and Width must not exceed 2000px.");
                        document.getElementById("bdimage").value = '';
                        return false;
                    }
                    // alert("Uploaded image has valid Height and Width.");
                    // return true;
                };
 
            }
        } else {
            alert("This browser does not support HTML5.");
            return false;
        }
    } else {
        alert("Please select a valid Image file.");
        return false;
    }
}