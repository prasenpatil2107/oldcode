<?php
class Home_model extends CI_Model{

 function __construct(){

	parent::__construct();

}

 function allslides(){
     $qry = $this->db->get_where('slides',array("status"=>1));
     $result = $qry->result_array();
     return $result;
 }

 function birthday(){
   $qry = $this->db->get('birthday');
   // $qry = $this->db->get_where('birthday',array("bdid"=>1));
   $result = $qry->result();
   return $result;
 }

 function events(){
   // $qry = $this->db->get('events');
  $currentDate = date("Y-m-d");
   $qry = "SELECT * FROM events WHERE status = 1 AND  (FromDate='$currentDate' OR ToDate = '$currentDate' OR '$currentDate' BETWEEN FromDate AND ToDate) ";
   $result = $this->db->query($qry)->result_array();
   return $result;
 }

 function getinterval()
 {
   $result=$this->db->get('settings');
   return $result->result();
 }

}
