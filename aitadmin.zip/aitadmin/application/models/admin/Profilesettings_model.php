<?php
class Profilesettings_model extends CI_Model{

 function __construct(){
	
	parent::__construct();
	
}

 function get_profile($id)
 {
     $qry = $this->db->get_where("admin_users",array('iId'=>$id));
     $result = $qry->result();
     return $result;
 }
 
 function countries()
 {
     $this->db->order_by("vTitle", "ASC"); 
     $qry = $this->db->get_where("admin_countries",array('eStatus'=>'1'));
     $result = $qry->result();
     return $result;
 }
 
 function states($id)
 {
     $this->db->order_by("vTitle", "ASC"); 
     $qry = $this->db->get_where("admin_states",array('eStatus'=>'1','iCountryId'=>$id));
     $result = $qry->result();
     return $result;
 }
 
 function get_country($id)
 {
     $qry = $this->db->get_where("admin_countries",array('iId'=>$id));
     $result = $qry->result();
     return $result;
 }
 
 function get_state($id)
 {
     $qry = $this->db->get_where("admin_states",array('iId'=>$id));
     $result = $qry->result();
     return $result;
 }
 
 
 
 function update($data, $id)
 {
     $this->db->where('iId', $id);
     $qry = $this->db->update("admin_users",$data);
     return $qry;
 }
 
 function check($password, $id)
 {
     $qry = $this->db->get_where("admin_users",array('iId'=>$id, 'vPassword'=>$password));
     $result = $qry->result();
     return $result;
 }
 
 function checkemailid($email, $id) {
        $this->db->where('iId !=', $id);
        $this->db->where('vEmailAddress', $email);
        $this->db->from('admin_users');
        return $this->db->count_all_results();
    }

	
}