<?php
class Slides_model extends CI_Model{

 function __construct(){

	parent::__construct();

}

 function add($data)
 {
    $qry = $this->db->insert("slides", $data);
    return $qry;
 }

 function update($data, $id)
 {
    $this->db->where('id', $id);
    $qry = $this->db->update("slides", $data);
    return $qry;
 }

 function delete($data, $id)
 {
    $this->db->where('id', $id);
    $qry = $this->db->update("slides", $data);
    return $qry;
 }

 function status($data, $id)
 {
    $this->db->where('id', $id);
    $qry = $this->db->update("slides", $data);
    return $qry;
 }

 function allslides(){
     $qry = $this->db->get_where('slides',array("status"=>1));
     $result = $qry->result();
     return $result;
 }

 function get_slide($id)
 {
    $qry = $this->db->get_where("slides", array("id" => $id));
    $result = $qry->result();
    return $result;
 }

 function get_slide1($id)
 {
    $qry = $this->db->get_where("settings", array("id" => $id));
    $result = $qry->result();
    return $result;
 }
 function add_birthday($data)
 {
   $qry = $this->db->insert("birthday", $data);
   return $this->db->insert_id();
 }

 function addsettings($data)
 {
    $qry = $this->db->insert("settings", $data);
    return $this->db->insert_id();
 }

 function get_parenttitle($id)
 {
    $this->db->select('vTitle');
    $qry = $this->db->get_where("slides", array("iId" => $id));
    $result = $qry->result();
    return $result;
 }

 function getinterval()
 {
   $result=$this->db->get('settings');
   return $result->result();
 }

 function updatesettings($id,$data)
 {
   $this->db->where('id',$id);
   $result=$this->db->update('settings',$data);
   return $result;
 }

 function slides_loaded($where = null, $order = null, $limit = null, $columns = null)
 {
     if($where)
         $where = $where." AND status!='0'";
     else
         $where = " WHERE status!='0'";

     $sql = "SELECT SQL_CALC_FOUND_ROWS `".str_replace(" , ", " ", implode("`, `", array_column($columns, 'db')))."` FROM `slides` $where $order $limit";
     $qry = $this->db->query($sql,'');

     $result = $qry->result();
     return $result;
 }

 function slides_count($where = null)
 {
     if($where)
         $where = $where." AND status!='0'";
     else
         $where = " WHERE status!='0'";

     $sql = "SELECT count(id) as cnt FROM `slides` $where";
     $qry = $this->db->query($sql,'');

     $result = $qry->result();
     return $result;
 }

 function all_category_dropdown($status = null)
 {
    $qry = $this->db->get_where("slides", array("eStatus" => $status));
    $result = $qry->result();
    return $result;
}

    function get_all_birthdays()
    {
        $qry = $this->db->get("birthday");
        $result = $qry->result_array();
        return $result;
    }

    // function get_all_events()
    // {
    //     $qry = $this->db->get("events");
    //     $result = $qry->result_array();
    //     return $result;
    // }

    // function event_add($data)
    //  {
    //    $qry = $this->db->insert("events", $data);
    //    return $this->db->insert_id();
    //  }

     function events_count($where = null)
     {
         if($where)
             $where = $where." AND status!='0'";
         else
             $where = " WHERE status!='0'";

         $sql = "SELECT count(id) as cnt FROM `events` $where";
         $qry = $this->db->query($sql,'');

         $result = $qry->result();
         return $result;
     }

     function events_loaded($where = null, $order = null, $limit = null, $columns = null)
     {
         if($where)
             $where = $where." AND status!='0'";
         else
             $where = " WHERE status!='0'";

         $sql = "SELECT SQL_CALC_FOUND_ROWS `".str_replace(" , ", " ", implode("`, `", array_column($columns, 'db')))."` FROM `events` $where $order $limit";
         $qry = $this->db->query($sql,'');

         $result = $qry->result();
         return $result;
     }

     function change_event_status($data, $id)
     {
        $this->db->where('id', $id);
        $qry = $this->db->update("events", $data);
        return $qry;
     }

      function get_event($id)
     {
        $qry = $this->db->get_where("events", array("id" => $id));
        $result = $qry->result();
        return $result;
     }

      function addevent($data)
     {
        $qry = $this->db->insert("events", $data);
        return $qry;
     }
      function updateEvent($data, $id)
     {
        $this->db->where('id', $id);
        $qry = $this->db->update("events", $data);
        return $qry;
     }


}       

