<?php
class Index_model extends CI_Model{

 function __construct(){
	
	parent::__construct();
	
}

 function login_check($username, $password)
 {

	$limit = 1;
	$offset = 0;
	
	$this->db->select('iId');
	$this->db->where("iRoleId!=","5");
	$result = $this->db->get_where('admin_users', array('vEmailAddress' => $username, 'eStatus' => 'y'), $limit, $offset);
	
	if($result->result())
	{
	
	$this->db->select('iId,iRoleId,vFirstName,vLastName,vEmailAddress');
	
	$result1 = $this->db->get_where('admin_users', array('vEmailAddress' => $username, 'vPassword' => $password), $limit, $offset);

	if($result1->result())
	 {
	   return $result1->result();
	 }
	 else return 1;
    }
	else
	{
            return 0;
	}
	
}
	
}