<?php

$bdate= date("m-d");
$sql1 = "SELECT bday_name,birthdate,bdimage FROM birthday WHERE SUBSTRING(birthdate,-5)='$bdate'";
$birthday1 = $this->db->query($sql1)->result_array();
 // echo "i". base_url(); 
///Thought of the Day////////////////////////////////////////////////////////////////////////////////
$currdate = date("Y-m-d");
$thoghtsql = "SELECT id FROM events WHERE EventName = 'Thought of the Day' AND CreatedDate = '$currdate' AND FromDate = '$currdate' AND ToDate = '$currdate' ";
$thought = $this->db->query($thoghtsql)->result_array();

if(is_array($thought)&&count($thought))
{
}
else{

          // die;
    if (! function_exists('imap_open')) {
      // echo "string";
    } else 
    {
              /* Connecting Gmail server with IMAP */
      if(
         $connection = imap_open('{imap.gmail.com:993/imap/ssl}INBOX', 'prasen.patil@aitglobalinc.com', 'dvyvdbvdvfoxvplk') or imap_open('{imap.gmail.com:993/imap/ssl}INBOX', 'prasen.patil@aitglobalinc.com', 'dokcgvikdcuckzgz')  or imap_open('{imap.gmail.com:993/imap/ssl}INBOX', 'prasen.patil@aitglobalinc.com', 'mnlplowmuhnrtioj') 
        )
        {
          
          $checkDate = date("d-M-Y");
          /* Search Emails having the specified keyword in the email subject */
          $emailData = imap_search($connection, 'SUBJECT "Thought of the Day" ON "'.$checkDate.'"');
          
          if (! empty($emailData)) {

             $count = 1;
            foreach ($emailData as $email_number) {
               
                $overview = imap_fetch_overview($connection, $email_number, 0);
                $message = imap_fetchbody($connection, $email_number, '1.1');

                 $structure = imap_fetchstructure($connection, $email_number);

                $attachments = array();

               /* if any attachments found... */
                if(isset($structure->parts) && count($structure->parts)) 
                {
                    for($i = 0; $i < count($structure->parts); $i++) 
                    {
                        $attachments[$i] = array(
                            'is_attachment' => false,
                            'filename' => '',
                            'name' => '',
                            'attachment' => ''
                        );

                        if($structure->parts[$i]->ifdparameters) 
                        {
                            foreach($structure->parts[$i]->dparameters as $object) 
                            {
                                if(strtolower($object->attribute) == 'filename') 
                                {
                                    $attachments[$i]['is_attachment'] = true;
                                    $attachments[$i]['filename'] = $object->value;
                                }
                            }
                        }

                        if($structure->parts[$i]->ifparameters) 
                        {
                            foreach($structure->parts[$i]->parameters as $object) 
                            {
                                if(strtolower($object->attribute) == 'name') 
                                {
                                    $attachments[$i]['is_attachment'] = true;
                                    $attachments[$i]['name'] = $object->value;
                                }
                            }
                        }

                        if($attachments[$i]['is_attachment']) 
                        {
                            $attachments[$i]['attachment'] = imap_fetchbody($connection, $email_number, $i+1);

                            /* 3 = BASE64 encoding */
                            if($structure->parts[$i]->encoding == 3) 
                            { 
                                $attachments[$i]['attachment'] = base64_decode($attachments[$i]['attachment']);
                            }
                            /* 4 = QUOTED-PRINTABLE encoding */
                            elseif($structure->parts[$i]->encoding == 4) 
                            { 
                                $attachments[$i]['attachment'] = quoted_printable_decode($attachments[$i]['attachment']);
                            }
                        }
                    }
                }

              /* iterate through each attachment and save it */
              $counter = 0;
                foreach($attachments as $attachment)
                {
                    if($counter<=1){
                        if($attachment['is_attachment'] == 1)
                        {
                            $filename = date("Ymdhis").".jpg";
                            $folder = "assets/images/";
                            $fp = fopen("./". $folder ."/". $filename, "w+");
                            fwrite($fp, $attachment['attachment']);
                            fclose($fp);
                            $Description = '<p><br></p><p><img src="http://welcome.aitglobalindia.com/assets/images/'.$filename.'" style="width: 862px;"><br></p>';
                            // echo "<br/>".
                            $insert = "INSERT INTO events SET EventName = 'Thought of the Day' , FromDate = '$currdate' , ToDate = '$currdate' , Description = '$Description' , isresponsive = '1' , status = '1' , CreatedBy = 'AIT' , CreatedDate = '$currdate' , UpdatedDate = '$currdate' , UpdatedBy = 'AIT' ";
                            $this->db->query($insert);

                        }
                    }
                    $counter++;
                }
            }

          }

        }
    }
}

/////////////////////////////////////////////////////////////////////////////////////////////////
 ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>AIT</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- css  -->
    <link rel="stylesheet" href="<?php echo base_url();?>publicthemes/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote-lite.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/slick.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/slick-theme.css" />
    <!-- <link rel="stylesheet" href="<?php //echo base_url();?>assets/css/bd_template.css"> -->

    <!-- Scripts -->
    <!-- include summernote css/js -->
    <script src="<?php echo base_url(); ?>assets/js/jquery.min.js" language="javascript"></script>
    <script src="<?php echo base_url(); ?>assets/js/popper.min.js" language="javascript"></script>
    <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js" language="javascript"></script>
    <script src="<?php echo base_url(); ?>assets/js/summernote-lite.js" language="javascript"></script>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote-lite.js"></script> -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>
    <style type="text/css">
      #block1 {
        overflow: hidden;
    }
    .slick-slide
{
width: 200px;
}
.slick-slide {
    width: 50vw;
    box-sizing: border-box;
}
      .slick-img-css, .slidr img{
      margin: 0 auto 0 auto !important;

      }

      .image-auto{
max-width:100%; height:auto; max-height:100%;
      }

      /*.slick-slide img{
          height: auto;
          width: auto;
          max-width: 300px;
          max-height: 300px;

      }*/
      
      .bday-img-holder{
/*        max-height: 750px;
        float: left;
        width: 100%;
        /*border: 3px solid black;
        overflow: hidden;*/
        width:100vw; height:55vh; /*display:table-cell;*/  vertical-align:middle; text-align:center;
      }
    </style>
</head>

<body>
    <input type="hidden" name="image_status" id="image_status" value="<?php echo $getinterval[0]->image_status; ?>" />
    <input type="hidden" name="time_interval" id="time_interval" value="<?php echo $getinterval[0]->time_interval; ?>" />
    <input type="hidden" name="font_size" id="font_size" value="<?php echo $getinterval[0]->font_size; ?>" />

    <script type="text/javascript">
        var time_interval = $( "#time_interval" ).val();
        console.log(time_interval);
        var font_size;
        font_size = $( "#font_size" ).val()+"px";
        console.log(font_size);

          var image_status = $( "#image_status" ).val();
          console.log(image_status);
          var image_stats;
          if(image_status=="1") {
            image_stats="block";
            console.log("Inside if");
          } else {
            image_stats="none";
            console.log("Inside else");
          }
    </script>

    <img style="padding:5%;" id="chai" src="assets/images/AIT_logo_india-new-1.png">

    <div id="slider_1">
    </div>

    <div class="container-fluid" style="background-color:#fff;">
      <div  class="row">

          <div  id="block1" class="slidr"  >
            <?php 
            $bdaycontainer = "bday-container";

            foreach($allslides as $slide){ 
              if($slide['isresponsive']=="0")
              {
                $bdaycontainer = "";
              }
                
              ?>
            <!-- <div class="looper"> -->
               <div  class ="slick-slide text-center <?php echo $bdaycontainer ?> " >
                 <!-- <div style="height: 500px; width:1024px;"> -->
                      <!-- <div class="img img-responsive"> -->
                        <?php echo $slide['description'];?>
                      <!-- </div> -->
                  <!-- </div> -->
              <!-- </div> -->
             </div>
           <?php } ?>

           <?php  foreach($birthday1 as $bd){ ?>
             <div class="text-center bday-container">
                 <h1 style=""><?php echo "Happy birthday !";?></h1>
                  <div class="bday-img-holder" style="">
                    <!-- <div class="img img-responsive"> -->
                      <img class="slick-img-css image-auto"  src="<?php echo base_url() . 'assets/images/'.$bd['bdimage'];?>"/>
                    <!-- </div> -->
                 </div>
                 <div><?php echo $bd['bday_name'];?></div>
              </div>
            <?php } ?>

            <?php
            $bdaycontainer = "bday-container";
             foreach($events as $event){
               if($event['isresponsive']=="0")
                {
                  $bdaycontainer = "";
                }
             ?>
              <!-- <div class="container-fluid"> -->
             <div  class="slick-slide text-center <?php echo $bdaycontainer ?>">
                <?php echo $event['Description'];?>
             </div>
           <!-- </div> -->
           <?php } ?>
          </div>
      </div>
    </div>

</body>

<!-- //////////////scrpits///////// -->
<script type="text/javascript">
  var a = [];
 function setImageViewPointHeight() {
// alert("kjcvnbjgfn")

  // var k = $("").attr( "data-slick-index" );
// k.addClass("class="bday-img-holder);
// console.log($("div.slick-slide .bday-container").find('p').children('img').parent());
$("div.slick-slide .bday-container").find('p').children('img').parent().addClass('bday-img-holder');
// $("div.slick-slide .bday-container").find('p').children('span').parent().addClass('slick-img-css image-auto');
$("div.slick-slide .bday-container").find('p').children('img').addClass('slick-img-css image-auto').css('width','auto');

    // $(".slick-slide p").each(function(index, p){
    //   // console.log($(p));
    //       // $(p).addClass("bday-img-holder");
         

    // });


  }

 


  $("#load").each(function() { var img = new Image(); img.src = this.src;  });
    document.getElementById("chai").style.display = image_stats;
    console.log("down");
</script>
<script>
  function myClick() {
  setTimeout(
    function() {
        location.reload();
    }, 210000);
}
myClick();

     var edit = function () {
            $('.click2edit').summernote({
                focus: true
            });
        };
    var save = function () {
        var markup = $('.click2edit').summernote('code');
        $('.click2edit').summernote('destroy');
    };
</script>

<script type="text/javascript">
      $(document).ready(function(){
        $('#block1').css('font-size',font_size);
        $('.slidr').slick({
          autoplay: true,
      // adaptiveHeight: true,
          autoplaySpeed:15000,
          mobileFirst: true
        // variableWidth: true,
        // variableHeight: true,
          // slidesToShow: 1
          // fade: true

        });
        setImageViewPointHeight();
      });
</script>
<script type="text/javascript">
//   $(window).on('resize orientationchange', function() {
//     // alert("kjfxnkgj")
//   $('.js-slider').slick('resize');
// });
  //  $(document).ready(function() {
  //   window.onresize = resizeSlideContainer;
  // });
  //  function getActiveSlideHeight() {
  //   var $slide = $(".views_slideshow_slide").filter(function(){
  //     if ( $(this).css("display") == "block" )
  //     {
  //       return $(this)
  //     }
  //   });
    
  //   return $slide.height();
  // };
  
  // function resizeSlideContainer() {
  //   var $slideContainer = $(".views-slideshow-cycle-main-frame");
  //   var slideHeight = getActiveSlideHeight();
  //   var slideContainerHeight = $slideContainer.height();
    
  //   if (slideContainerHeight != slideHeight)
  //   {
  //     $slideContainer.height(slideHeight);
  //   }
  // };
</script>
</html>
