<?php //$this->load->view('templates/include_head'); ?>
<?php
if (isset($editedrow) && ($editedrow != '')) {

    $title_value = $editedrow[0]->vTitle;
    $sts_value = $editedrow[0]->eStatus;
    $idv = $edited_id;
    $formact = base_url() . "categoriesedit/$idv";
    $cattitle = "Edit";
} else {
    $title_value = "";
    $banner_value = "";
    $icon_value = "";
	$svg_value = "";
    $parent_value = "";
    $sts_value = "";
    $pagetitle_value = "";
    $metakey_value = "";
    $metadesc_value = "";
    $idv = "";
    $formact = base_url() . "admin/main/newslide_add";
    $cattitle = "Add New";
}
?>
<body>
<div id="page-container" class="header-fixed-top sidebar-partial sidebar-visible-lg sidebar-no-animations">
    <div id="sidebar">
        <div class="sidebar-scroll">
            <?php $this->load->view('templates/include_leftnav'); ?>
        </div>
    </div>
    <div id="main-container">
        <?php //$this->load->view('templates/include_header'); ?>
        <div id="page-content">
            <ul class="breadcrumb breadcrumb-top">
                <li> <a href="<?php echo base_url() ;?>main"> Dashboard </a></li>
                <li> <a href="<?php echo base_url() ;?>categories"> Slides </a></li>
                <li> Add New Slide </li>
            </ul>
            <div class="content-header ">
                <div class="header-section">
                    <div class="row">
                        <div class="col-sm-8">
                            <h4><i class="fa fa-list-ol margin-right-10"></i> <strong>Slides</strong></h4>
                        </div>
                        <div class="col-sm-4 text-right"> <a href="<?php echo base_url() . "categories"; ?>" class="btn btn-info"><i class="fa fa-reply margin-right-10"></i>Go to Categories</a> </div>
                    </div>
                </div>
            </div>
            <div class="margin-bottom-30"> <?php
			if ($this->session->flashdata('add_successupdate')) {
				echo '<div class="row" id="alert-message-block">
					<div id="alert-message" class="alert alert-success">Data Updated successfully.</div>
				</div>';
			}
			if ($this->session->flashdata('add_success')) {
				echo '<div class="row" id="alert-message-block">
					<div id="alert-message" class="alert alert-success">Data inserted successfully.</div>
				</div>';
			}
			if ($this->session->flashdata('add_error')) {
				echo '<div class="row" id="alert-message-block">
					<div id="alert-message" class="alert alert-danger">Error ! please try again</div>
				</div>';
			}
			echo form_open("$formact", array("id" => "form_add", "name" => "form_add", "class" => "form-horizontal", "enctype" => "multipart/form-data")); ?>
                <div class=" block full margin-top-20">
                    <div class="block-title lightcol">
                        <div class="row">
                            <div class="col-sm-12">
                                <h4 class="margin-top-0"><strong><i class="gi gi-plus margin-right-10"></i> <?php echo $cattitle; ?> Category</strong></h4>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="Cat-title" class="col-md-4 control-label text-right">Category Title<span class="star">*</span></label>
                                <div class="col-md-8"> <?php echo form_input(array("id" => "cat_title", "name" => "cat_title", "class" => "required form-control", "value" => $title_value, "maxlength" => "75", "minlength" => "3")); ?> </div>
                            </div>
                        </div>

                    </div>

                    <div class="row">

                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="Cat-Status" class="col-md-4 control-label text-right">Status</label>
                                <div class="col-md-8">
                                    <select class="form-control" name="status" id="status">
                                        <option value="1" <?php if (($sts_value == '1') || ($sts_value == '')) echo "selected=selected"; ?>>Publish</option>
                                        <option value="2" <?php if ($sts_value == '2') echo "selected=selected"; ?>>Draft</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group form-actions text-center">
                    <button class="btn btn-primary" type="submit"><i class="fa fa-angle-right"></i> Submit</button>
                    <?php if($idv =='') { ?>
                    <button class="btn btn-default" type="reset"><i class="fa fa-repeat"></i> Reset</button>
                    <?php } ?>
                </div>
                <?php echo form_close(); ?> </div>
        </div>

    </div>
</div>
