<?php //$this->load->view('templates/include_head'); ?>
<?php
if (isset($editedrow) && ($editedrow != '')) {

    $image_status = $editedrow[0]->image_status;
    $time_interval = $editedrow[0]->time_interval;
    $font_size = $editedrow[0]->font_size;
    $id = 1;
    $formact = base_url() . "slidesettings_add/$id";
} else {
    $image_status = "";
    $time_interval = "";
    $font_size = "";
    $id = "";
    $formact = base_url() . "admin/main/slidesettings_add";
}
?>

        <div id="page-content">
            <div class="content-header ">
                <div class="header-section">
                    <div class="row">
                        <div class="col-sm-8">
                            <h4><i class="fa fa-list-ol margin-right-10"></i> <strong>Settings page</strong></h4>
                        </div>
                        <div class="col-sm-4 text-right"> <a href="<?php echo base_url() . "slides"; ?>" class="btn btn-info"><i class="fa fa-reply margin-right-10"></i>Go to All Slides</a> </div>
                    </div>
                </div>
            </div>
            <div class="margin-bottom-30"> <?php
			if ($this->session->flashdata('add_successupdate')) {
				echo '<div class="row" id="alert-message-block">
					<div id="alert-message" class="alert alert-success">Data Updated successfully.</div>
				</div>';
			}
			if ($this->session->flashdata('add_success')) {
				echo '<div class="row" id="alert-message-block">
					<div id="alert-message" class="alert alert-success">Data inserted successfully.</div>
				</div>';
			}
			if ($this->session->flashdata('add_error')) {
				echo '<div class="row" id="alert-message-block">
					<div id="alert-message" class="alert alert-danger">Error ! please try again</div>
				</div>';
			}
			echo form_open("$formact", array("id" => "form_add", "name" => "form_add", "class" => "form-horizontal", "enctype" => "multipart/form-data")); ?>
                <div class=" block full margin-top-20">
                    <div class="block-title lightcol">
                        <div class="row">
                            <div class="col-sm-12">
                                <h4 class="margin-top-0"><strong><i class="gi gi-plus margin-right-10"></i> <?php echo $cattitle; ?> Image</strong></h4>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6 margin-top-20">
                            <div class="form-group">
                                <label for="Cat-title" class="col-md-4 control-label text-right">Image status<span class="star">*</span></label>
                                <div class="col-md-8"> <?php echo form_checkbox(array("id" => "cat_title", "name" => "cat_title", "class" => "required", "value" => $title_value, "minlength" => "3")); ?> </div>
                            </div>
                        </div>
                         <div class="col-sm-12 col-md-offset-1">
                          <div class="form-group">
                            <label  for="Cat-ad-type" class="col-md-1">Time Interval<span class="star">*</span></label>
                            <div class="col-md-4"><?php echo form_input(array("id" => "cat_title","placeholder"=>"Enter numeric value", "name" => "cat_title", "class" => "required form-control", "value" => $title_value, "maxlength" => "75", "minlength" => "3")); ?> </div>
                        </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6 margin-top-20">
                            <div class="form-group">
                                <label for="Cat-title" class="col-md-4 control-label text-right">Font size<span class="star">*</span></label>
                                <div class="col-md-8"> <?php echo form_input(array("id" => "cat_title","placeholder"=>"Enter numeric value", "name" => "cat_title", "class" => "required form-control", "value" => $title_value, "maxlength" => "75", "minlength" => "3")); ?> </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group form-actions text-center">
                    <button class="btn btn-primary" type="submit"><i class="fa fa-angle-right"></i> Submit</button>
                    <?php if($idv =='') { ?>
                    <button class="btn btn-default" type="reset"><i class="fa fa-repeat"></i> Reset</button>
                    <?php } ?>
                </div>
                <?php echo form_close(); ?> </div>
        </div>

    </div>
</div>
