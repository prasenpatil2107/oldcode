<?php //$this->load->view('templates/include_head'); ?>
<?php
if (isset($editedrow) && ($editedrow != '')) {

    $title_value = $editedrow[0]->title;
    $description = $editedrow[0]->description;
    $sts_value = $editedrow[0]->status;
    $isresponsive = $editedrow[0]->isresponsive;
    $idv = $edited_id;
    $formact = base_url() . "slideedit/$idv";
    $cattitle = "Edit";
} else {
    $title_value = "";
    $description = "";
    $sts_value = "";
    $isresponsive = "";
    $idv = "";
    $formact = base_url() . "admin/main/newslide_add";
    $cattitle = "Add New";
}
?>

        <div id="page-content">

            <div class="content-header ">
                <div class="header-section">
                    <div class="row">
                        <div class="col-sm-8">
                            <h4><i class="fa fa-list-ol margin-right-10"></i> <strong>Slides</strong></h4>
                        </div>
                        <div class="col-sm-4 text-right"> <a href="<?php echo base_url() . "slides"; ?>" class="btn btn-info"><i class="fa fa-reply margin-right-10"></i>Go to All Slides</a> </div>
                    </div>
                </div>
            </div>
            <div class="margin-bottom-30"> <?php
			if ($this->session->flashdata('add_successupdate')) {
				echo '<div class="row" id="alert-message-block">
					<div id="alert-message" class="alert alert-success">Data Updated successfully.</div>
				</div>';
			}
			if ($this->session->flashdata('add_success')) {
				echo '<div class="row" id="alert-message-block">
					<div id="alert-message" class="alert alert-success">Data inserted successfully.</div>
				</div>';
			}
			if ($this->session->flashdata('add_error')) {
				echo '<div class="row" id="alert-message-block">
					<div id="alert-message" class="alert alert-danger">Error ! please try again</div>
				</div>';
			}
			echo form_open("$formact", array("id" => "form_add", "name" => "form_add", "class" => "form-horizontal", "enctype" => "multipart/form-data")); ?>
                <div class=" block full margin-top-20">
                    <div class="block-title lightcol">
                        <div class="row">
                            <div class="col-sm-12">
                                <h4 class="margin-top-0"><strong><i class="gi gi-plus margin-right-10"></i> <?php echo $cattitle; ?> Slide</strong></h4>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6 margin-top-20">
                            <div class="form-group">
                                <label for="Cat-title" class="col-md-4 control-label text-right">Title<span class="star">*</span></label>
                                <div class="col-md-8"> <?php echo form_input(array("id" => "cat_title", "name" => "cat_title", "class" => "required form-control", "value" => $title_value, "maxlength" => "75", "minlength" => "3")); ?> </div>
                            </div>
                        </div>

                         <div class="col-sm-12 col-md-offset-1">
                          <div class="form-group">
                            <label  for="Cat-ad-type" class="col-md-1">Description<span class="star">*</span></label>
                            <div class="col-md-10"> <?php echo form_textarea(array("id" => "textarea-wysiwyge", "name" => "description", "rows" => "6", "class" => " form-control textarea-editor required", "value" => $description, "maxlength" => "", "minlength" => "")); ?> </div>
                        </div>
                        </div>
                    </div>
<!-- 
                    <div class="row">
                      <div class="col-sm-6 margin-top-20">
                          <div class="form-group">
                              <label for="Cat-title" class="col-md-4 control-label text-right">Image Upload<span class="star">*</span></label>
                              <input type="file" name="fileToUpload" id="fileToUpload">
                        </div>
                      </div>
                    </div> -->
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="Cat-Status" class="col-md-4 control-label text-right">Is Image Responsive</label>
                                <div class="col-md-8">
                                    <select class="form-control" name="isresponsive" id="isresponsive">
                                        <option value="1" <?php if (($isresponsive == '1') || ($isresponsive == '')) echo "selected=selected"; ?>>Responsive</option>
                                        <option value="0" <?php if ($isresponsive == '0') echo "selected=selected"; ?>>Original Size</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="Cat-Status" class="col-md-4 control-label text-right">Status</label>
                                <div class="col-md-8">
                                    <select class="form-control" name="status" id="status">
                                        <option value="1" <?php if (($sts_value == '1') || ($sts_value == '')) echo "selected=selected"; ?>>Publish</option>
                                        <option value="2" <?php if ($sts_value == '2') echo "selected=selected"; ?>>Draft</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group form-actions text-center">
                    <button class="btn btn-primary" type="submit"><i class="fa fa-angle-right"></i> Submit</button>
                    <?php if($idv =='') { ?>
                    <button class="btn btn-default" type="reset"><i class="fa fa-repeat"></i> Reset</button>
                    <?php } ?>
                </div>
                <?php echo form_close(); ?> </div>
        </div>

    </div>
</div>
