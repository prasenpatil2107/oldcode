<?php //$this->load->view('templates/include_head'); ?>
<?php
if (isset($editedrow) && ($editedrow != '')) {

    $image_status = $editedrow[0]->image_status;
    $time_interval = $editedrow[0]->time_interval;
    $font_size = $editedrow[0]->font_size;
    $id = 1;
    $formact = base_url() . "slidesettings_add/$id";
} else {
    $image_status = "";
    $time_interval = "";
    $font_size = "";
    $id = "";
    $formact = base_url() . "admin/main/birthday_add1";
}
?>

        <div id="page-content">
            <div class="content-header ">
                <div class="header-section">
                    <div class="row">
                        <div class="col-sm-8">
                            <h4><i class="fa fa-list-ol margin-right-10"></i> <strong>Settings page</strong></h4>
                        </div>
                        <div class="col-sm-4 text-right"> <a href="<?php echo base_url() . "slides"; ?>" class="btn btn-info"><i class="fa fa-reply margin-right-10"></i>Go to All Slides</a> </div>
                    </div>
                </div>
            </div>
            <div class="margin-bottom-30"> <?php
			if ($this->session->flashdata('add_successupdate')) {
				echo '<div class="row" id="alert-message-block">
					<div id="alert-message" class="alert alert-success">Data Updated successfully.</div>
				</div>';
			}
			if ($this->session->flashdata('add_success')) {
				echo '<div class="row" id="alert-message-block">
					<div id="alert-message" class="alert alert-success">Data inserted successfully.</div>
				</div>';
			}
			if ($this->session->flashdata('add_error')) {
				echo '<div class="row" id="alert-message-block">
					<div id="alert-message" class="alert alert-danger">Error ! please try again</div>
				</div>';
			}
             ?>
            <h3>Uplod CSV</h3>

                 <form action="<?php echo base_url(); ?>admin/main/bulkuploadbirthday" method="post" enctype="multipart/form-data" autocomplete="off" id="popup-validation" onsubmit="ShowLoading();" >
                                                <!-- text input -->                                        
                    <div class="form-group" style="clear:both">
                        <label for="RecieptFile_New">Browse File<span class="required">*</span></label>
                        <input type="file" name="bdayfile" id="bdayfile"><br/>
                        <p class="help-block"><i>Note : Please attach CSV File Only</i></p>
                    </div>
                    
                    <div class="box-footer" style="clear:both" >
                        <button type="submit" class="btn btn-primary"><i class="fa fa-check-circle"></i> Upload</button>
                        <a href="<?php echo base_url(); ?>admin/main/sampleformat"><button type="button" class="btn btn-primary"><i class="fa fa-check-circle"></i> Sample Format</button></a>
                    </div>                                      
                </form>

            <?php
			echo form_open("$formact", array("id" => "form_add", "name" => "form_add", "class" => "form-horizontal", "enctype" => "multipart/form-data","autocomplete"=>"off")); ?>
                <div class=" block full margin-top-20">
                    <div class="block-title lightcol">
                        <div class="row">
                            <div class="col-sm-12">
                                <h4 class="margin-top-0"><strong><i class="gi gi-plus margin-right-10"></i> <?php/* echo $cattitle;*/ ?> Birthday</strong></h4>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6 margin-top-20">
                            <div class="form-group">
                                <label for="Cat-title" class="col-md-4 control-label text-right">Name<span class="star">*</span></label>
                                <div class="col-md-8"> <?php echo form_input(array("id" => "bday_name_id","placeholder"=>"Enter name", "name" => "bday_name", "class" => "required form-control", "maxlength" => "75", "minlength" => "3")); ?> </div>
                            </div>
                        </div>
                         <div class="col-sm-12 col-md-offset-1">
                          <div class="form-group">
                            <label  for="Cat-ad-type" class="col-md-1 control-label text-right">Birth Date<span class="star">*</span></label>
                            <div class="col-md-4"><?php echo form_input(array("id" => "birthday","placeholder"=>"Enter numeric value", "name" => "birthdate", "class" => "required form-control","readonly"=>"readonly")); ?> </div>
                        </div>
                        </div>

                        <div class="col-sm-6 margin-top-20">
                            <div class="form-group">
                                <label for="Cat-title" class="col-md-4 control-label text-right">Image<span class="star">*</span></label>
                                <div class="col-md-8"> <?php echo form_upload(array("id" => "bdimage", "name" => "bdimage", "class" => "required form-control","onchange" =>"return img_Uploadcheck();")); ?> </div>
                            </div>
                        </div>
                    </div>

                    <!-- /Prasen Code here/// -->
                    

                    <!-- <div class="row">

                    </div> -->
                </div>

                <div class="form-group form-actions text-center">
                    <button class="btn btn-primary" type="submit" ><i class="fa fa-angle-right"></i> Submit</button>
                    <button class="btn btn-default" type="reset"><i class="fa fa-repeat"></i> Reset</button>
                </div>
                <?php echo form_close(); ?> </div>
        </div>
        <div class="margin-bottom-30">
                        <div class=" block full margin-top-20 tablepadding-20b">
                            <div class="block-title lightcol">
                                <div class="row">
                                    <div class="col-sm-9">
                                        <h4 class="margin-top-0">Birthday's List - <strong id='totalrec'></strong></h4>
                                        <span id="suc_message">
                                        <?php
                                                    if ($this->session->flashdata('add_successupdate')) {
                                                        echo "<span class='success_msg errpadding'> Status Changed successfully.</span>";
                                                    }
                                                    if ($this->session->flashdata('add_error')) {
                                                        echo "<span class='error_msg errpadding'>Error ! please try again </span>";
                                                    }
                                               ?>
                                        </span> </div>
                                </div>
                                  <div class="row">
            <div class="container-fluid">
                <div class="col-md-12">
                    <table id="birthday_list" class="table table-bordered table-striped" >
                        <?php
                        $counter=1;
                        if((is_array($birthday_list)) &&(count($birthday_list)))
                        { 
                        ?>
                            <thead>
                                <tr>
                                    <th>Sr.No</th>
                                    <th>Photo</th>
                                    <th>Name</th>
                                    <th>Date of Birth</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                
                                foreach ($birthday_list as $d)
                                {
                                ?>
                                    <tr>
                                        <td class=\"align-center\"><?php echo $counter;?></td>
                                        
                                        <td><img src="<?php echo base_url(); ?>assets/images/<?php echo $d['bdimage']; ?>" width="80px" height="80px" /></td>
                                        <td><?php echo $d['bday_name'];?></td>
                                        <td><?php echo $d['birthdate'];?></td>
                                        <?php $counter++; ?>
                                        <td>
                                        <?php 
                                        $itemid=$d['bdid'];
                                        // echo $editurl = '<a data-original-title="Edit" href="'.base_url().'admin/main/editbday('.$itemid.')" data-toggle="tooltip" title="Edit" class="btn btn-sm btn-warning"><i class="fa fa-pencil"></i></a> &nbsp;&nbsp; ';
                                        $deleteevent = "deletebday('".$itemid."')";
                                        echo $deleteurl = '<a onclick="'.$deleteevent.'" data-original-title="Delete item" data-toggle="tooltip" title="Delete" class="btn btn-sm btn-danger deleterecord"><i class="fa fa-times"></i></a>';

                                        ?>
                                        </td>
                                    </tr>
                                <?php
                                }
                                ?>
                            </tbody>
                        <?php
                        } 
                        else
                        { 
                        ?>
                            <h4 class = "errors">Oops..!!! No Record Found</h4><br/>
                        <?php 
                        }
                        ?>
                    </table>
                </div>
            </div>
        </div>
                            </div>

                        </div>

                    </div>
      
    </div>
</div>
<script type="text/javascript">
function deletebday(id)
{
    if(confirm('Do you want to delete this record ?')){
        var params = {id:id}
        $.ajax({
            url: '<?php echo base_url(); ?>admin/main/deletebday',
            type: 'post',
            dataType: 'json',
            data: params,
            success: function (r) {
                if(r.status=="true")
                {
                    alert("Deleted successfully !");
                    location.reload();
                }
            }
        });
    }
}
</script>
