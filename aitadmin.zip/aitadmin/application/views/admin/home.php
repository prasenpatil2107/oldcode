<!DOCTYPE html>
<html lang="en">

<head>
    <title>AIT Global</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- css  -->
    <link rel="stylesheet" href="<?php echo base_url();?>publicthemes/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote-lite.css" rel="stylesheet">
    <!-- <link rel="stylesheet" href="css/tempusdominus-bootstrap-4.min.css" /> -->
    <!--     <link rel="stylesheet" href="/plugins/_shared/fontawesome/5.0.12/css/fontawesome-all.css">
    <link rel="stylesheet" href="/plugins/_shared/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="/plugins/_shared/css/responsive.dataTables.min.css">
    <link rel="stylesheet" href="/plugins/_shared/css/jquery-ui.css">
 -->

    <!--     <link rel="stylesheet" type="text/css" href="/plugins/_shared/fontawesome-icon-picker/css/jquery.fonticonpicker.min.css"
    />
    <link rel="stylesheet" type="text/css" href="/plugins/_shared/fontawesome-icon-picker/css/jquery.fonticonpicker.bootstrap.min.css"
    />
    <link rel="stylesheet" type="text/css" href="/plugins/_shared/fontawesome-icon-picker/css/font-awesome-icons.css" /> -->



    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/slick.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/slick-theme.css" />



    <!-- Scripts -->


    <!-- include summernote css/js -->
    <!-- <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script> -->
    <script src="<?php echo base_url(); ?>assets/js/jquery.min.js" language="javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/popper.min.js" language="javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js" language="javascript"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/slick.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote-lite.js"></script>


    <script>

         var edit = function () {
                $('.click2edit').summernote({
                    focus: true
                });
            };

            var save = function () {
                var markup = $('.click2edit').summernote('code');
                $('.click2edit').summernote('destroy');
            };
    </script>

</head>

<body>

    <div class="slider autoplay mt-10" style="text-align:center;">
    <?php foreach($thoughtoftheday as $thought){ ?>
        <div style="background-color:white">
           <?php echo $thought->description;?></div>
    <?php } ?>
    <input type="hidden" name="time_interval" id="time_interval" value="<?php echo $getinterval[0]->time_interval; ?>" />
    </div>


</body>

</html>
<script>
    var time_interval = $( "#time_interval" ).val();
    console.log(time_interval);
    $('.autoplay').slick({
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    autoplay: true,
                    autoplaySpeed:time_interval
                });
</script>
