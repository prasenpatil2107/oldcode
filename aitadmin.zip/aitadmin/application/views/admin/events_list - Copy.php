

    <div id="page-content">
        <ul class="breadcrumb breadcrumb-top">
                <li> <a href="<?php echo base_url() ;?>main"> Dashboard </a></li>
                <li> Events </li>
            </ul>
            <div class="content-header ">
                <div class="header-section">
                    <div class="row">
                        <div class="col-sm-6">
                            <h4><i class="fa fa-list-ol margin-right-10"></i> <strong>All Events</strong></h4>
                        </div>

                         
                        <div class="col-sm-6 text-right"> <a href="javascript:void(0)" id="searchrefresh" onClick="javascript:SearchOrgLoad()" class="btn btn-default" style="display:none"> <i class="fa fa-refresh margin-right-10"></i> Refresh </a> <a href="<?php echo base_url() ?>" class="btn btn-info"><i class="fa fa-reply margin-right-10"></i>Go To Slider</a> <a href="<?php echo base_url().'addevent' ?>" class="btn btn-success"><i class="fa fa-plus margin-right-10"></i>Add New Event</a> </div>
                    </div><!-- <a href="#SearchPopup" data-toggle="modal"  class="btn btn-info"><i class="fa fa-search margin-right-10"></i>Search</a> -->
                </div>
            </div>
             <div class="row" id="alert-message-block" style="display:none;">
                <div id="alert-message" class="alert"> </div>
            </div>
           <!--  <div class="row">
                <div class="block-options pagenav text-center col-sm-12" id='filtersrch'> <a class="btn btn-sm btn-alt btn-default active" href="javascript:void(0)" p="all">ALL</a>
                    <?php for ($i = 65; $i <= 90; $i++) { ?>
                    <a class="btn btn-sm btn-alt btn-default" href="javascript:void(0)" p='<?php echo chr($i); ?>'> <?php echo chr($i); ?> </a>
                    <?php } ?>
                </div>
            </div> -->
            <div class="margin-bottom-30">
                <div class=" block full margin-top-20 tablepadding-20b">
                    <div class="block-title lightcol">
                        <div class="row">
                            <div class="col-sm-9">
                                <h4 class="margin-top-0">Total Events - <strong id='totalrec'></strong></h4>
                                <span id="suc_message">
                                <?php
                                            if ($this->session->flashdata('add_successupdate')) {
                                                echo "<span class='success_msg errpadding'> Status Changed successfully.</span>";
                                            }
                                            if ($this->session->flashdata('add_error')) {
                                                echo "<span class='error_msg errpadding'>Error ! please try again </span>";
                                            }
                                       ?>
                                </span> </div>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table id="datatable_ajax_events" class="table table-vcenter table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Event</th>
                                    <th>From Date</th>
                                    <th>To Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- <div id="SearchPopup" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header text-center">
                        <h2 class="modal-title text-left"><i class="fa fa-search"></i> Search</h2>
                    </div>
                    <div class="modal-body">
                        <form action="" method="post" enctype="multipart/form-data" class="form-horizontal form-bordered" onSubmit="return true;">
                            <fieldset>
                            <div class="form-group">
                                <div class="col-sm-6 col-md-4 margin-bottom-10">
                                    <input type="text" name="catid" id="catid" placeholder="Category ID" class="form-control">
                                </div>
                                <div class="col-sm-6 col-md-4 margin-bottom-10">
                                    <input type="text" name="title" id="title" placeholder="Title" class="form-control">
                                </div>
                                <div class="col-sm-6 col-md-4 margin-bottom-10">
                                    <input type="text" name="posteddate" id="posteddate" placeholder="Posted Date" data-date-format="yyyy-mm-dd" class="form-control input-datepicker" >
                                </div>
                            </div>
                            </fieldset>
                            <div class="form-group form-actions">
                                <div class="col-xs-12 text-right">
                                    <button type="button" class="btn btn-sm btn-default" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-sm btn-primary" data-dismiss="modal" id="searchitems"><i class="fa fa-search margin-right-10"></i>Search</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div> -->
        
    </div>
</div>
<script type="text/javascript">
    function deleteevents(encodedata){
        var target_row = $(this).closest("tr").get(0); // this line did the trick
        if(confirm('Do you want to delete this record ?')){
                $.ajax
                ({
                    type: "POST",
                    url: site_url+'admin/main/deleteevents',
                    data: "id=" + encodedata,
                    success: function(msg)
                    {
                        var oTable = $('#datatable_ajax_events').DataTable();
                        oTable.row(target_row).remove().draw( true );
                        alert_message('success','Record is Deleted Sucessfully.');

                    }
                });
        }
    }

</script>