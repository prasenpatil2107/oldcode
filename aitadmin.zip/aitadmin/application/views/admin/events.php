<?php //$this->load->view('templates/include_head'); ?>
<?php
if (isset($editedrow) && ($editedrow != '')) {

    $image_status = $editedrow[0]->image_status;
    $time_interval = $editedrow[0]->time_interval;
    $font_size = $editedrow[0]->font_size;
    $id = 1;
    $formact = base_url() . "slidesettings_add/$id";
} else {
    $image_status = "";
    $time_interval = "";
    $font_size = "";
    $id = "";
    $formact = base_url() . "admin/main/event_add";
}
?>

        <div id="page-content">
            <div class="content-header ">
                <div class="header-section">
                    <div class="row">
                        <div class="col-sm-8">
                            <h4><i class="fa fa-list-ol margin-right-10"></i> <strong>Settings page</strong></h4>
                        </div>
                        <div class="col-sm-4 text-right"> <a href="<?php echo base_url() . "slides"; ?>" class="btn btn-info"><i class="fa fa-reply margin-right-10"></i>Go to All Slides</a> </div>
                    </div>
                </div>
            </div>
            <div class="margin-bottom-30"> <?php
			if ($this->session->flashdata('add_successupdate')) {
				echo '<div class="row" id="alert-message-block">
					<div id="alert-message" class="alert alert-success">Data Updated successfully.</div>
				</div>';
			}
			if ($this->session->flashdata('add_success')) {
				echo '<div class="row" id="alert-message-block">
					<div id="alert-message" class="alert alert-success">Data inserted successfully.</div>
				</div>';
			}
			if ($this->session->flashdata('add_error')) {
				echo '<div class="row" id="alert-message-block">
					<div id="alert-message" class="alert alert-danger">Error ! please try again</div>
				</div>';
			}
			echo form_open("$formact", array("id" => "form_add", "name" => "form_add", "class" => "form-horizontal", "enctype" => "multipart/form-data")); ?>
                <div class=" block full margin-top-20">
                    <div class="block-title lightcol">
                        <div class="row">
                            <div class="col-sm-12">
                                <h4 class="margin-top-0"><strong><i class="gi gi-plus margin-right-10"></i> <?php/* echo $cattitle;*/ ?> Events</strong></h4>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6 margin-top-20">
                            <div class="form-group">
                                <label for="Cat-title" class="col-md-4 control-label text-right">Event Name<span class="star">*</span></label>
                                <div class="col-md-8"> <?php echo form_input(array("id" => "EventName","placeholder"=>"Enter Event Name", "name" => "EventName", "class" => "required form-control", "maxlength" => "75", "minlength" => "3")); ?> </div>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-offset-1">
                          <div class="form-group">
                                <label  for="Cat-ad-type" class="col-md-1 control-label text-right">From Date<span class="star">*</span></label>
                                <div class="col-md-4"><?php echo form_input(array("id" => "birthday","placeholder"=>"Enter numeric value", "name" => "FromDate", "class" => "required form-control","readonly"=>"readonly")); ?> </div>
                            </div>
                        </div>

                        <div class="col-sm-12 col-md-offset-1">
                          <div class="form-group">
                                <label  for="Cat-ad-type" class="col-md-1 control-label text-right">To Date<span class="star">*</span></label>
                                <div class="col-md-4"><?php echo form_input(array("id" => "birthday2","placeholder"=>"Enter numeric value", "name" => "ToDate", "class" => "required form-control","readonly"=>"readonly")); ?> </div>
                            </div>
                        </div>

                        <div class="col-sm-6 margin-top-20">
                            <div class="form-group">
                                <label for="Cat-title" class="col-md-4 control-label text-right">Image<span class="star">*</span></label>
                                <div class="col-md-8"> <?php echo form_upload(array("id" => "EventImage", "name" => "EventImage", "class" => "required form-control", "maxlength" => "75", "minlength" => "3")); ?> </div>
                            </div>
                        </div>
                    </div>

                    <!-- /Prasen Code here/// -->
                    

                    <!-- <div class="row">

                    </div> -->
                </div>

                <div class="form-group form-actions text-center">
                    <button class="btn btn-primary" type="submit"><i class="fa fa-angle-right"></i> Submit</button>
                    <button class="btn btn-default" type="reset"><i class="fa fa-repeat"></i> Reset</button>
                </div>
                <?php echo form_close(); ?> </div>
        </div>
        <div class="margin-bottom-30">
                        <div class=" block full margin-top-20 tablepadding-20b">
                            <div class="block-title lightcol">
                                <div class="row">
                                    <div class="col-sm-9">
                                        <h4 class="margin-top-0">Event List  <strong id='totalrec'></strong></h4>
                                    </div>
                                </div>
            <div class="row">
            <div class="container-fluid">
                <div class="col-md-12">
                    <table id="event_list" class="table table-bordered table-striped" >
                        <?php
                        $counter=1;
                        if((is_array($event_list)) &&(count($event_list)))
                        { 
                        ?>
                            <thead>
                                <tr>
                                    <th>Sr.No</th>
                                    <th>Event</th>
                                    <th>Photo</th>
                                    <th>From - To Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                
                                foreach ($event_list as $d)
                                {
                                ?>
                                    <tr>
                                        <td class=\"align-center\"><?php echo $counter;?></td>
                                        
                                        <td><img src="<?php echo base_url(); ?>assets/images/<?php echo $d['EventImage']; ?>" width="80px" height="80px" /></td>
                                        <td><?php echo $d['EventName'];?></td>
                                        <td><?php echo date("d-m-Y", strtotime($d['FromDate']))."-".date("d-m-Y", strtotime($d['ToDate']));?></td>
                                        <?php $counter++; ?>
                                        <td>
                                        <?php 
                                        $itemid=$d['Id'];
                                        // echo $editurl = '<a data-original-title="Edit" href="'.base_url().'admin/main/editbday('.$itemid.')" data-toggle="tooltip" title="Edit" class="btn btn-sm btn-warning"><i class="fa fa-pencil"></i></a> &nbsp;&nbsp; ';
                                        $deleteevent = "deleteEvent('".$itemid."')";
                                        echo $deleteurl = '<a onclick="'.$deleteevent.'" data-original-title="Delete item" data-toggle="tooltip" title="Delete" class="btn btn-sm btn-danger deleterecord"><i class="fa fa-times"></i></a>';

                                        ?>
                                        </td>
                                    </tr>
                                <?php
                                }
                                ?>
                            </tbody>
                        <?php
                        } 
                        else
                        { 
                        ?>
                            <h4 class = "errors">Oops..!!! No Record Found</h4><br/>
                        <?php 
                        }
                        ?>
                    </table>
                </div>
            </div>
        </div>
                            </div>

                        </div>

                    </div>
      
    </div>
</div>
<script type="text/javascript">
function deleteEvent(id)
{
    if(confirm('Do you want to delete this record ?')){
        var params = {id:id}
        $.ajax({
            url: '<?php echo base_url(); ?>admin/main/deleteEvent',
            type: 'post',
            dataType: 'json',
            data: params,
            success: function (r) {
                if(r.status=="true")
                {
                    alert("Deleted successfully !");
                    location.reload();
                }
            }
        });
    }
}
</script>
