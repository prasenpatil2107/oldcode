
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php print_r(date('Y-m-d')) ?>
    <img src="<?php echo('../aitadmin/assets/images/parvez.jpg');?>" />
  </body>
</html>
