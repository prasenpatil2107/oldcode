<style>
.dropdownmore ul.dropdown-menu li a{ width:25% !important; } 
</style> 
<header class="navbar navbar-default navbar-fixed-top">
  <div class="navbar-header">
    <ul class="nav navbar-nav-custom pull-right visible-sm visible-xs">
      <li><a href="javascript:void(0)" data-toggle="collapse" data-target="#horizontal-menu-collapse">Menu</a></li>
    </ul>
    <ul class="nav navbar-nav-custom">
      <li><a href="javascript:void(0)" onClick="App.sidebar('toggle-sidebar');"> <i class="fa fa-bars fa-fw"></i></a></li>
    </ul>
  </div>
  <div id="horizontal-menu-collapse" class="collapse navbar-collapse">
    <ul class="nav navbar-nav">
      <!--<li <?php if($classtopid == 0) { echo 'class="active"'; } ?>  ><a href="<?php echo base_url()."main"; ?>"><i class="fa fa-home"></i></a></li>
      <li <?php if($classtopid == 1) { echo 'class="active"'; } ?>><a href="<?php echo base_url()."categories"; ?>">Categories</a></li>-->
     
       <?php
        $userinformation = userinfo();
        if($userinformation[0]->iRoleId==1) { ?> 
      
      <!--<li <?php if($classtopid == 9) { echo 'class="active"'; } ?>><a href="<?php echo base_url()."users"; ?>">Users</a></li>-->
        <?php } ?>
     
      <!--<li <?php //if($classtopid == 7) { echo 'class="active"'; } ?>><a href="#">Job/Placement</a></li>-->
      </ul>
      
      </li>
     
    </ul>
    <ul class="nav navbar-nav pull-right">
      <li class="dropdown"><a data-toggle="dropdown" class="dropdown-toggle" href="javascript:void(0)"> <i class="fa fa-gear"></i> <span class="hidden-lg">Settings</span></a>
        <ul class="dropdown-menu">
          <!--<li><a href="<?php echo base_url()."globalsettings.html"; ?>" ><i class="fa fa-globe fa-fw pull-right"></i> Global Settings</a></li>
          <li><a href="<?php echo base_url()."profilesettings.html"; ?>"><i class="fa fa-user fa-fw pull-right"></i> Profile Settings</a></li>-->
          <li><a href="<?php echo base_url()."logout"; ?>" ><i class="fa fa-power-off fa-fw pull-right"></i> Logout</a></li>
        </ul>
      </li>
      <li class="hidden-xs"><span class="login_tit"><strong>Welcome</strong> <?php $userinformation = userinfo(); echo $userinformation[0]->vFirstName." (".$userinformation[0]->rolename.")"; ?></span></li>
    </ul>
  </div>
</header>
