<!DOCTYPE html>
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if IE 9]>         <html class="no-js lt-ie10"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
          <title>AIT ADMIN</title>
         <meta name="description" content="iCertify">
        <meta name="author" content="iCertify">
        <meta name="robots" content="noindex, nofollow">
         <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">
         <link rel="shortcut icon" href="<?php echo base_url();?>publicthemes/img/favicon.ico">
        <link rel="apple-touch-icon" href="<?php echo base_url();?>publicthemes/img/icon57.png" sizes="57x57">
        <link rel="apple-touch-icon" href="<?php echo base_url();?>publicthemes/img/icon72.png" sizes="72x72">
        <link rel="apple-touch-icon" href="<?php echo base_url();?>publicthemes/img/icon76.png" sizes="76x76">
        <link rel="apple-touch-icon" href="<?php echo base_url();?>publicthemes/img/icon114.png" sizes="114x114">
        <link rel="apple-touch-icon" href="<?php echo base_url();?>publicthemes/img/icon120.png" sizes="120x120">
        <link rel="apple-touch-icon" href="<?php echo base_url();?>publicthemes/img/icon144.png" sizes="144x144">
        <link rel="apple-touch-icon" href="<?php echo base_url();?>publicthemes/img/icon152.png" sizes="152x152">
         <link rel="stylesheet" href="<?php echo base_url();?>publicthemes/css/bootstrap.min.css">
         <link rel="stylesheet" href="<?php echo base_url();?>publicthemes/css/plugins.css">
         <link rel="stylesheet" href="<?php echo base_url();?>publicthemes/css/main.css">
         <link rel="stylesheet" href="<?php echo base_url();?>publicthemes/css/custom.css">
         <link rel="stylesheet" href="<?php echo base_url();?>publicthemes/css/layout.css">
        <link rel="stylesheet" href="<?php echo base_url();?>publicthemes/css/themes.css">
        <link rel="stylesheet" href="<?php echo base_url();?>assets/js/responsiveeditor/editor.css">
        <link rel="stylesheet" href="<?php echo base_url();?>assets/datepicker/css/datepicker.css">
        <link rel="stylesheet" href="<?php echo base_url();?>assets/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css">
       <script src="<?php echo base_url();?>publicthemes/js/vendor/modernizr-2.7.1-respond-1.4.2.min.js"></script>
       <!-- <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote-lite.css" rel="stylesheet"> -->
       <link href="<?php echo base_url();?>assets/css/summernote-lite.css" rel="stylesheet">

	   <script>var site_url  = '<?php echo base_url();?>';</script>
    </head>
<body>
<div id="page-container" class="header-fixed-top sidebar-partial sidebar-visible-lg sidebar-no-animations">
    <div id="sidebar">
        <div class="sidebar-scroll">
        <?php $this->load->view('templates/include_leftnav'); ?>
        </div>
    </div>
    <div id="main-container">
        <?php $this->load->view('templates/include_header'); ?>
	<?php echo $body;?>
</body>
</html>
<script src="<?php echo base_url(); ?>assets/js/jquery.min.js" language="javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery-min.2.0.js" language="javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/popper.min.js" language="javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js" language="javascript"></script>
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote-lite.js"></script> -->
<script src="<?php echo base_url(); ?>assets/js/jquery.dataTables.min.js" language="javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery.validate.min.js" language="javascript"></script>
<script src="<?php echo base_url() ?>assets/js/responsiveeditor/editor.js"></script>
<script src="<?php echo base_url(); ?>assets/js/summernote-lite.js" language="javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/scripts.js" language="javascript"></script>
<script src="<?php echo base_url(); ?>assets/datepicker/js/bootstrap-datepicker.js" language="javascript"></script>
