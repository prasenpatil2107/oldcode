<!DOCTYPE html>
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if IE 9]>         <html class="no-js lt-ie10"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
          <title>Deals Portal</title>
         <meta name="description" content="iCertify">
        <meta name="author" content="iCertify">
        <meta name="robots" content="noindex, nofollow">
         <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">
         <link rel="shortcut icon" href="<?php echo base_url();?>publicthemes/img/favicon.ico">
        <link rel="apple-touch-icon" href="<?php echo base_url();?>publicthemes/img/icon57.png" sizes="57x57">
        <link rel="apple-touch-icon" href="<?php echo base_url();?>publicthemes/img/icon72.png" sizes="72x72">
        <link rel="apple-touch-icon" href="<?php echo base_url();?>publicthemes/img/icon76.png" sizes="76x76">
        <link rel="apple-touch-icon" href="<?php echo base_url();?>publicthemes/img/icon114.png" sizes="114x114">
        <link rel="apple-touch-icon" href="<?php echo base_url();?>publicthemes/img/icon120.png" sizes="120x120">
        <link rel="apple-touch-icon" href="<?php echo base_url();?>publicthemes/img/icon144.png" sizes="144x144">
        <link rel="apple-touch-icon" href="<?php echo base_url();?>publicthemes/img/icon152.png" sizes="152x152">
         <link rel="stylesheet" href="<?php echo base_url();?>publicthemes/css/bootstrap.min.css">
         <link rel="stylesheet" href="<?php echo base_url();?>publicthemes/css/plugins.css">
         <link rel="stylesheet" href="<?php echo base_url();?>publicthemes/css/main.css">
         <link rel="stylesheet" href="<?php echo base_url();?>publicthemes/css/custom.css">
         <link rel="stylesheet" href="<?php echo base_url();?>publicthemes/css/layout.css">
        <link rel="stylesheet" href="<?php echo base_url();?>publicthemes/css/themes.css">
       <script src="<?php echo base_url();?>publicthemes/js/vendor/modernizr-2.7.1-respond-1.4.2.min.js"></script>
    </head>
