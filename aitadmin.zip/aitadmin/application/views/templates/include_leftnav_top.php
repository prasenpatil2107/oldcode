<a href="<?php echo base_url().'/admin/'; ?>" class="sidebar-brand"><i class="gi gi-flash"></i><strong>AIT</strong> ADMIN</a>
  <div class="sidebar-section sidebar-user clearfix">
    <div class="sidebar-user-avatar"> 
        
        <a href="#"> 
        <?php
        $userinformation = userinfo();
        if($userinformation[0]->vProfileImage) { ?> 
        <img src="<?php echo base_url()."resources/profiles/small/".$userinformation[0]->vProfileImage; ?>" alt="profile"> 
        <?php } else { ?><img src="<?php echo base_url()."publicthemes/img/profilepic.png" ?>" alt="profile"> <?php } ?>
        </a>

    </div>
    <div class="sidebar-user-name">
        <?php echo $userinformation[0]->vFirstName;  ?>
    </div>
    <div class="sidebar-user-links"> 
        <!--<a href="<?php echo base_url().'profilesettings'; ?>" data-toggle="modal" class="enable-tooltip" data-placement="bottom" title="Profile Settings"><i class="gi gi-user"></i></a> 
        <a href="<?php echo base_url().'profilesettings/updateprofile/changepass/true.html'; ?>" data-toggle="modal" class="enable-tooltip" data-placement="bottom" title="Change Password"><i class="gi gi-lock"></i></a>
        <a href="<?php echo base_url().'index/logout.html'; ?>" data-toggle="tooltip" data-placement="bottom" title="Logout"><i class="gi gi-exit"></i></a>--> </div>
  </div>