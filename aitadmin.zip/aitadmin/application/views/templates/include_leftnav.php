<div class="sidebar-content">
<?php  $this->load->view('templates/include_leftnav_top'); ?>
  <ul class="sidebar-nav">
    <li class="sidebar-header"><span class="sidebar-header-title">Quick Links</span></li>
    <li><a href="<?php echo base_url()."slides"; ?>"><i class="gi gi-tag sidebar-nav-icon"></i>All Slides</a></li>
    <li><a href="<?php echo base_url()."addslide"; ?>"><i class="fa fa-caret-right margin-right-5 margin-left-15"></i>Add Slides</a></li>
    <!-- <li><a href="<?php echo base_url()."addslide1"; ?>"><i class="fa fa-caret-right margin-right-5 margin-left-15"></i>Settings</a></li> -->
    <!-- <li><a href="<?php echo base_url()."imageupload"; ?>"><i class="fa fa-caret-right margin-right-5 margin-left-15"></i>Image Upload</a></li> -->
    <li><a href="<?php echo base_url()."birthday"; ?>"><i class="fa fa-caret-right margin-right-5 margin-left-15"></i>Birthday</a></li>
    <li><a href="<?php echo base_url()."events"; ?>"><i class="fa fa-caret-right margin-right-5 margin-left-15"></i>Events</a></li>
    <!--<li><a href="<?php echo base_url()."birthdaymessages"; ?>"><i class="fa fa-caret-right margin-right-5 margin-left-15"></i>Birthday Messages</a></li>
    <li><a href="<?php echo base_url()."welcomemessages"; ?>"><i class="fa fa-caret-right margin-right-5 margin-left-15"></i>Welcome Messages</a></li>
    <li><a href="<?php echo base_url()."specialmessages"; ?>"><i class="fa fa-caret-right margin-right-5 margin-left-15"></i>Special Messages</a></li>-->

  </ul>
  <ul class="sidebar-nav">
    <li class="sidebar-header"><span class="sidebar-header-title">Other Links</span></li>
	<!--<li <?php //if($classleftid == 104) { echo 'class="active"'; } ?>><a href="<?php //echo base_url().'global_banners'; ?>"><i class="hi hi-picture sidebar-nav-icon"></i>Home Banners</a></li>

    <li <?php //if($classleftid == 101) { echo 'class="active"'; } ?>><a href="<?php //echo base_url().'profilesettings'; ?>"><i class="gi gi-user sidebar-nav-icon"></i>Profile Settings</a></li>-->
    <li <?php if($classleftid == 102) { echo 'class="active"'; } ?>><a href="<?php echo base_url().'logout'; ?>"><i class="fa fa-power-off sidebar-nav-icon"></i>Logout</a></li>
  </ul>
</div>
