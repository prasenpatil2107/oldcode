<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller
{

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 *
	 */
	public function __construct()
       {
           parent::__construct();
		   if(!$this->session->userdata("logged_in"))
		   {
			  redirect("admin");
		   }
		   else
		   {
			$userinformation = userinfo();
			$this->fname = $userinformation[0]->vFirstName;
			$this->userid = $userinformation[0]->iId;
			$this->role = $userinformation[0]->iRoleId;
		   }


           $template['classleftid'] = ''; $template['classleftid_in'] = '';  $template['classtopid'] = '';
           $this->load->model('admin/slides_model');
           $this->load->library("encrypt");
       }
	public function index()
	   {
		   $data = array('title'=>'Slides','classleftid'=>'1.23','classleftid_in'=>'1.0','classtopid'=>'1');

		   $this->template->load('common','admin/slides_list',$data);
	   }

	public function slides()
	   {

		   $data = array('title'=>'Slides','classleftid'=>'1.23','classleftid_in'=>'1.0','classtopid'=>'1');

		   $this->template->load('common','admin/slides_list',$data);
	   }


	public function formdata($id = null)
	   {
			if($id)
			{
			$allslides = $this->slides_model->get_slide($id);
			$editslide = $allslides;

			}
			else{
				$editslide = "";
				$allslides = "";
			}
			$data = array('title'=>'Slide Add','allslideslist' =>$allslides,'classleftid'=>'1.23','classleftid_in'=>'1.0','classtopid'=>'1','edited_id'=>$id,'editedrow'=>$editslide);

			$this->template->load('common','admin/addslide',$data);
	    }

		public function imageupload()
			{
				echo "Inside imageupload";
				$this->load->view('admin/imageupload.php');
			}

			public function birthday()
			{
					$this->load->library('upload');
					$birthday_list = $this->slides_model->get_all_birthdays();
					$data = array('title'=>'birthday','classleftid'=>'1.23','classleftid_in'=>'1.0','classtopid'=>'1','birthday_list'=>$birthday_list);
					$this->template->load('common','admin/birthday',$data);
			}

		public function imageprocess()
			{
				echo "Inside imageprocess";
			}

		public function settingload($id = 1)
		   {
				if($id)
				{

				$allslides = $this->slides_model->get_slide1($id);
				$editslide = $allslides;

				}
				else{
					$editslide = "";
					$allslides = "";
				}
				$data = array('title'=>'Slide Add','classleftid'=>'1.23','classleftid_in'=>'1.0','classtopid'=>'1','edited_id'=>$id,'editedrow'=>$allslides);

				$this->template->load('common','admin/addslide1',$data);
			}

	public function settings_add()
	   {
				 if($this->input->post()){
					extract($this->input->post());
					$userdata = userinfo();
					$this->posteddata = array(

					"image_status"=>$image_status,
					"time_interval"=>$time_interval,
					"font_size"=>$font_size,
				);

				$result = $this->slides_model->addsettings($this->posteddata);
				if($result){

					$this->session->set_flashdata('add_success', TRUE);
					redirect(base_url()."admin/main/settingload/".$result);
				}
				else {
					$this->session->set_flashdata('add_error', TRUE);
					redirect(base_url()."admin/main/settingload");
				}
				}
	    }

			public function settings_update($id)
				 {

					 	 print_r($this->input->post());
						 if($this->input->post()){
							extract($this->input->post());
							$userdata = userinfo();
							$this->posteddata = array(

							"image_status"=>$this->input->post('image_status'),
							"time_interval"=>$time_interval,
							"font_size"=>$font_size,
						);
						$result = $this->slides_model->updatesettings($id,$this->posteddata);
						if($result){

							$this->session->set_flashdata('add_successupdate', TRUE);
							redirect(base_url()."admin/main/settingload/".$result);
						}
						else {
							$this->session->set_flashdata('add_error', TRUE);
							redirect(base_url()."admin/main/settingload");
						}
						}
					}

	public function slideedit($id)
	    {
			if($this->input->post())
			{
				extract($this->input->post());
				$userdata = userinfo();
				$this->posteddata = array(
				"title"=>$cat_title,
				"description" =>$description,
				"status"=>$status,
				"isresponsive"=>$isresponsive,
				"updated_by"=>$userdata[0]->vFirstName,
				"updated_date"=> date("Y-m-d")
				);
			     $result = $this->slides_model->update($this->posteddata, $id);

					if($result)
					{
						$this->session->set_flashdata('add_successupdate', TRUE);
						redirect(base_url()."admin/main/formdata/$id");
					}
					else
					{
						$this->session->set_flashdata('add_error', TRUE);
						redirect(base_url()."admin/main/formdata/$id");
					}
	       }
        }
	public function birthday_add1()
	{
		if($this->input->post()){
			extract($this->input->post());
				if(is_array($_FILES))
				 {
					if(is_uploaded_file($_FILES['bdimage']['tmp_name']))
					 {
						$sourcePath = $_FILES['bdimage']['tmp_name'];
						$textfield="Bday-".date("Ymdhis").".jpg";
						$targetPath = "assets/images/".$textfield;
						if(move_uploaded_file($sourcePath,$targetPath)) 
						 {
							
						 }
			         }
				 }
				 else
				 {
				 	$textfield = "";
				 }
			$userdata = userinfo();
			$this->posteddata = array(
			"bday_name"=>$bday_name,
			"birthdate"=> $birthdate,
			"bdimage"=>$textfield,
			);
			$result = $this->slides_model->add_birthday($this->posteddata);
			if($result){
				$this->session->set_flashdata('add_success', TRUE);
				redirect(base_url()."birthday");
			}
			else {
			$this->session->set_flashdata('add_error', TRUE);
			redirect(base_url()."birthday");
			}
		}
	}
	public function deletebday()
	{
		$id = $this->input->post('id');
		$this->db->where('bdid', $id);
		$this->db->delete('birthday');
		$res['status'] = "true";
		echo json_encode($res);
	}
	public function newslide_add()
	   {

			if($this->input->post()){
				extract($this->input->post());
				$userdata = userinfo();
				$this->posteddata = array(
				"title"=>$cat_title,
				"description"=>$description,
				"status"=>$status,
				"isresponsive"=>$isresponsive,
				"created_by"=>$userdata[0]->vFirstName,
				"created_date"=> date("Y-m-d")

			);

			$result = $this->slides_model->add($this->posteddata);

			if($result){

			$this->session->set_flashdata('add_success', TRUE);
			redirect(base_url()."slides");
			}
			else {
			$this->session->set_flashdata('add_error', TRUE);
			redirect(base_url()."slides");
			}
			}
	   }


	public function ajaxdelete()
	   {

			$id = $this->input->post('id');
			$data = array(
			'status' => "0"
			);
			$this->slides_model->delete($data,$id);
			echo "Deleted succcessfully.";
	   }

	public function ajaxchangestatus()
	   {
			$id = $this->input->post('id');
			$status = $this->input->post('status');

			if ($status == 1)
				$sts = 1;
			else
				$sts = 2;

			$this->posteddata = array("status" => "$sts");
			$result = $this->slides_model->status($this->posteddata, $id);

			if ($result) {
				echo "Updated status successfully.";
			} else {
				echo "Status not updated.";
			}
       }

	public function loadslides()
        {

					$columns = array(
						array( 'db' => 'id',  'dt' => 0 ),
						array( 'db' => 'title',  'dt' => 1 ),
						array( 'db' => 'created_by',  'dt' => 2 ),
						array( 'db' => 'created_date',  'dt' => 3 ),
						array( 'db' => 'status',  'dt' => 4 ));

					$sIndexColumn = "id";
					$_GET['iDisplayStart'] = $_GET['start'];
					$_GET['iDisplayLength'] = $_GET['length'];

				/*** Paging  ***/

					$sLimit = "";
				if ( isset( $_GET['iDisplayStart'] ) && $_GET['iDisplayLength'] != '-1' )
				{
					$sLimit = "LIMIT ".intval( $_GET['iDisplayStart'] ).", ".
						intval( $_GET['iDisplayLength'] );
				}

				/*** Ordering ***/

					$request = $_GET; $order = ''; $sOrder = '';

					if ( isset($request['order']) && count($request['order']) ) {
							$orderBy = array();

							$dtColumns = pluck( $columns, 'dt' ); // Global Helper
							for ( $i=0, $ien=count($request['order']) ; $i<$ien ; $i++ ) {
									// Convert the column index into the column data property
									$columnIdx = intval($request['order'][$i]['column']);
									$requestColumn = $request['columns'][$columnIdx];
									$columnIdx = array_search( $requestColumn['data'], $dtColumns );
									$column = $columns[ $columnIdx ];
									if ( $requestColumn['orderable'] == 'true' ) {
											$dir = $request['order'][$i]['dir'] === 'desc' ?
													'ASC' :
													'DESC';
											$orderBy[] = '`'.$column['db'].'` '.$dir;
									}
							}
							$order = 'ORDER BY '.implode(', ', $orderBy);
					}
					//return $order;

				/*** Filtering  ***/
				$sWhere = "";
				if ( isset($_GET['search']['value']) && $_GET['search']['value'] != "" )
				{
						if(strlen($_GET['search']['value']) > 5)
						{
							$searchitems = explode("{{-}}",$_GET['search']['value']);

							$sWhere = "WHERE (";

							if($searchitems[0]!='' && $searchitems[0]!='undefined')
							$sWhere .= "`id` = '".trim( $searchitems[0] )."' AND ";

							if($searchitems[1]!='' && $searchitems[1]!='undefined')
							$sWhere .= "`title` LIKE '".trim( $searchitems[1] )."%' AND ";

							if($searchitems[2]!='' && $searchitems[2]!='undefined')
							$sWhere .= "`created_date` = '".trim( $searchitems[2] )."' AND ";

							$sWhere = rtrim($sWhere, "AND ");

							$sWhere .= ')';
						}
						else
						{
					$sWhere = "WHERE (";
					$sWhere .= "`title` LIKE '".trim( $_GET['search']['value'] )."%' OR ";
					$sWhere = substr_replace( $sWhere, "", -3 );
					$sWhere .= ')';
						}
				}

					$count = $this->slides_model->slides_count($sWhere);
					$iTotal = $count[0]->cnt;
					$iFilteredTotal = $count[0]->cnt;

				$resultdata = $this->slides_model->slides_loaded($sWhere, $order, $sLimit, $columns);
					//print_r($resultdata);exit;
					$output = array(
					"draw" => intval($_GET['draw']),
					"recordsTotal" => $iTotal,
					"recordsFiltered" => $iFilteredTotal,
					"data" => array()
				);


			foreach($resultdata as $aRow)
				{
						$itemid = $aRow->id;

						if ($aRow->status == 1) {
							$clickevent = "changestatus(2,'".$itemid."')";
							$status = '<a id="staus'.$itemid.'" onClick="'.$clickevent.'" data-original-title="Status - Active"  data-toggle="tooltip" title="Status - Active" class="btn btn-sm btn-success status-btn"><i class="fa fa-star"></i></a>';
						} else {
							$clickevent = "changestatus(1,'".$itemid."')";
							$status = '<a id="staus'.$itemid.'" onClick="'.$clickevent.'" data-original-title="Status - InActive" data-toggle="tooltip" title="Status - InActive" class="btn btn-sm btn-default status-btn"><i class="fa fa-star cold2"></i></a>';
						}
						$viewtitle = '<a data-original-title="View" href="'.base_url().'admin/main/view/'.$itemid.'" data-toggle="tooltip" title="View" >'.$aRow->title.'</a>';
						$editurl = '<a data-original-title="Edit" href="'.base_url().'admin/main/formdata/'.$itemid.'" data-toggle="tooltip" title="Edit" class="btn btn-sm btn-warning"><i class="fa fa-pencil"></i></a>';
						$deleteevent = "deleterecord('".$itemid."')";
						$deleteurl = '<a onclick="'.$deleteevent.'" data-original-title="Delete item" data-toggle="tooltip" title="Delete" class="btn btn-sm btn-danger deleterecord"><i class="fa fa-times"></i></a>';


						$output["data"][] = array(
						$aRow->id,
						$aRow->title,
						$aRow->created_by,
						$aRow->created_date,
						"<div class='btn-group'><span style='float:left;' id='status-flag-" .$itemid. "'>".$status."</span>".$editurl.$deleteurl."</div>"
						);

				}
				echo json_encode($output);
	   }
	public function descImguploads(){
		// print_r($_FILES['files']['name']);exit;
		if (isset($_FILES["files"]['name']) && ($_FILES["files"]['name'] != '')) {
				$name = md5(rand(100, 200));
        $ext = explode('.', $_FILES['files']['name']);
        $filename = $name . '.' . $ext[1];
				$config['upload_path'] = './assets/images/';
				$config['allowed_types'] = '*';
				$config['max_size']     = '5000';
				$config['max_width'] = '';
				$config['max_height'] = '';

				$this->load->library('upload', $config);
		    $this->upload->initialize($config);

			 if (!empty($_FILES['files']['name'])) {

					$upload = $this->upload->do_upload('files');

					if ($upload === TRUE) {
						$data2 = $this->upload->data();
					} else{
						$data2['file_name'] = '';
					}
					$textfield =  $data2['file_name'];
					//echo $textfield;
					echo base_url().'assets/images/' . $textfield;//change this URL
						} else {
							echo  $message = 'Ooops!  Your upload triggered the following error:  '.$_FILES['files']['error'];
						}

					 }

	}

	////EVENTS

		public function events()
		{
			$data = array('title'=>'Events','classleftid'=>'1.23','classleftid_in'=>'1.0','classtopid'=>'1');
			$this->template->load('common','admin/events_list',$data);
		}

		public function loadevents()
		{
			$columns = array(
			array( 'db' => 'id',  'dt' => 0 ),
			array( 'db' => 'EventName',  'dt' => 1 ),
			array( 'db' => 'FromDate',  'dt' => 2 ),
			array( 'db' => 'ToDate',  'dt' => 3 ),
			array( 'db' => 'status',  'dt' => 4 ));

			$sIndexColumn = "id";
			$_GET['iDisplayStart'] = $_GET['start'];
			$_GET['iDisplayLength'] = $_GET['length'];

			/*** Paging  ***/

					$sLimit = "";
				if ( isset( $_GET['iDisplayStart'] ) && $_GET['iDisplayLength'] != '-1' )
				{
					$sLimit = "LIMIT ".intval( $_GET['iDisplayStart'] ).", ".
						intval( $_GET['iDisplayLength'] );
				}

				/*** Ordering ***/

					$request = $_GET; $order = ''; $sOrder = '';

					if ( isset($request['order']) && count($request['order']) ) {
							$orderBy = array();

							$dtColumns = pluck( $columns, 'dt' ); // Global Helper
							for ( $i=0, $ien=count($request['order']) ; $i<$ien ; $i++ ) {
									// Convert the column index into the column data property
									$columnIdx = intval($request['order'][$i]['column']);
									$requestColumn = $request['columns'][$columnIdx];
									$columnIdx = array_search( $requestColumn['data'], $dtColumns );
									$column = $columns[ $columnIdx ];
									if ( $requestColumn['orderable'] == 'true' ) {
											$dir = $request['order'][$i]['dir'] === 'desc' ?
													'ASC' :
													'DESC';
											$orderBy[] = '`'.$column['db'].'` '.$dir;
									}
							}
							$order = 'ORDER BY '.implode(', ', $orderBy);
					}
					//return $order;

				/*** Filtering  ***/
				$sWhere = "";
					$count = $this->slides_model->events_count($sWhere);
					$iTotal = $count[0]->cnt;
					$iFilteredTotal = $count[0]->cnt;

				$resultdata = $this->slides_model->events_loaded($sWhere, $order, $sLimit, $columns);
					$output = array(
					"draw" => intval($_GET['draw']),
					"recordsTotal" => $iTotal,
					"recordsFiltered" => $iFilteredTotal,
					"data" => array()
				);


			foreach($resultdata as $aRow)
				{
						// echo "ll".
						$itemid = $aRow->id;

						if ($aRow->status == 1) {
							$clickevent = "change_event_status(2,'".$itemid."')";
							$status = '<a id="staus'.$itemid.'" onClick="'.$clickevent.'" data-original-title="Status - Active"  data-toggle="tooltip" title="Status - Active" class="btn btn-sm btn-success status-btn"><i class="fa fa-star"></i></a>';
						} else {
							$clickevent = "change_event_status(1,'".$itemid."')";
							$status = '<a id="staus'.$itemid.'" onClick="'.$clickevent.'" data-original-title="Status - InActive" data-toggle="tooltip" title="Status - InActive" class="btn btn-sm btn-default status-btn"><i class="fa fa-star cold2"></i></a>';
						}
						// $viewtitle = '<a data-original-title="View" href="'.base_url().'admin/main/view/'.$itemid.'" data-toggle="tooltip" title="View" >'.$aRow->title.'</a>';
						$editurl = '<a data-original-title="Edit" href="'.base_url().'admin/main/formeventdata/'.$itemid.'" data-toggle="tooltip" title="Edit" class="btn btn-sm btn-warning"><i class="fa fa-pencil"></i></a>';
						$deleteevent = "deleteevents('".$itemid."')";
						$deleteurl = '<a onclick="'.$deleteevent.'" data-original-title="Delete item" data-toggle="tooltip" title="Delete" class="btn btn-sm btn-danger deleteevents"><i class="fa fa-times"></i></a>';


						$output["data"][] = array(
						$aRow->id,
						$aRow->EventName,
						$aRow->FromDate,
						$aRow->ToDate,
						"<div class='btn-group'><span style='float:left;' id='status-flag-" .$itemid. "'>".$status."</span>".$editurl.$deleteurl."</div>"
						);

				}
				// die;
				echo json_encode($output);
	   	}

	   	public function change_event_status()
		{		
			$id = $this->input->post('id');
			$status = $this->input->post('status');

			if ($status == 1)
				$sts = 1;
			else
				$sts = 2;

			$this->posteddata = array("status" => "$sts");
			$result = $this->slides_model->change_event_status($this->posteddata, $id);

			if ($result) {
				echo "Updated status successfully.";
			} else {
				echo "Status not updated.";
			}
       }

       public function deleteevents()
	   {

			$id = $this->input->post('id');
			$data = array(
			'status' => "0"
			);
			$id = $this->input->post('id');
			$this->db->where('id', $id);
			$qry = $this->db->update("events", $data);

			echo "Deleted succcessfully.";
	   }

		public function formeventdata($id = null)
	   	{
			if($id)
			{
			$allslides = $this->slides_model->get_event($id);
			$editslide = $allslides;

			}
			else{
				$editslide = "";
				$allslides = "";
			}
			$data = array('title'=>'Event Add','allslideslist' =>$allslides,'classleftid'=>'1.23','classleftid_in'=>'1.0','classtopid'=>'1','edited_id'=>$id,'editedrow'=>$editslide);

			$this->template->load('common','admin/addevent',$data);
	    }

    	public function newevent_add()
	   {

			if($this->input->post()){
				extract($this->input->post());
				$userdata = userinfo();
				$this->posteddata = array(
				"EventName"=>$EventName,
				"FromDate"=>$FromDate,
				"ToDate"=>$ToDate,
				"Description"=>$Description,
				"status"=>$status,
				"isresponsive"=>$isresponsive,
				"CreatedBy"=>$userdata[0]->vFirstName,
				"CreatedDate"=> date("Y-m-d")

			);

			$result = $this->slides_model->addevent($this->posteddata);

			if($result){

			$this->session->set_flashdata('add_success', TRUE);
			redirect(base_url()."events");
			}
			else {
			$this->session->set_flashdata('add_error', TRUE);
			redirect(base_url()."events");
			}
			}
	   }

	   	public function eventedit($id)
	    {
			if($this->input->post())
			{
				extract($this->input->post());
				$userdata = userinfo();
				$this->posteddata = array(
				"EventName"=>$EventName,
				"FromDate"=>$FromDate,
				"ToDate"=>$ToDate,
				"Description"=>$Description,
				"isresponsive"=>$isresponsive,
				"status"=>$status,
				"UpdatedBy"=>$userdata[0]->vFirstName,
				"UpdatedDate"=> date("Y-m-d")
				);
			     $result = $this->slides_model->updateEvent($this->posteddata, $id);

					if($result)
					{
						$this->session->set_flashdata('add_successupdate', TRUE);
						redirect(base_url()."admin/main/formeventdata/$id");
					}
					else
					{
						$this->session->set_flashdata('add_error', TRUE);
						redirect(base_url()."admin/main/formeventdata/$id");
					}
	       }
        }
///Birthday//////////////////////////////////////////////////////////////////
	public function bulkuploadbirthday()
	{
		if(isset( $_FILES['bdayfile']))
		{
			$file = $_FILES [ 'bdayfile' ];
			$file_name = $file['name'];
			$file_tmp = $file['tmp_name'];
			$file_size = $file['size'];
			$file_error = $file['error'];
			
			$file_ext = explode('.',$file_name);
			$filename = strtolower($file_ext[0]);
			
			$file_ext = strtolower(end($file_ext));
			
			$allowed = array('csv');
			
			if(in_array( $file_ext, $allowed))
			{
				if($file_error === 0)
				{
					if($file_size <= 20971524)
					{
						$file_name_new = $filename.'.'.$file_ext;
						$file_destination = 'bulk_upload/'.$file_name_new;
						
						if(move_uploaded_file($file_tmp, $file_destination))
						{
							$fileInput = file_get_contents( 'bulk_upload/'. $file_name_new );
							$Lines = explode( "\r\n", $fileInput );
							for( $i = 0; $i < count($Lines); $i++ )
							{	
								set_time_limit(0);
								$data = explode(",", $Lines[$i]);
								$toUpload = [];
								if( $i!=0 and !empty($Lines[$i] ) )
								{
									$bday_name = trim( $data[0] );
									$birthdate = trim( $data[1] );
									$bdimage = trim( $data[2] ).".jpg" ;
									$insert = "INSERT INTO birthday SET bday_name = '$bday_name' , birthdate = '$birthdate' , bdimage = '$bdimage' ";
									$this->db->query($insert);
								}
							}
						}
						// return true;
						// $handle = file_get_contents('/bulk_upload/'.$file_name_new,"r");
					}
				}
			}
		}
		HEADER("LOCATION: /aitadmin/birthday");
	            exit;
	}


	public function sampleformat() {
		$this->load->helper('download');
		$path = 'BulkBirthDayUpload.csv';
		$data = file_get_contents("download/BulkBirthDayUpload.csv");
		force_download($path,$data);
	}


}
