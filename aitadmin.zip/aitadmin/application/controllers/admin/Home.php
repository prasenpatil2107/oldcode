<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 

/**
 * Index Class
 *
  */
class Home extends CI_Controller {
	public function __construct() {
		parent::__construct();
	}
	
	/**
	 * Takes user to the admin panel
	 *
	 * @param       -----
	 * @return      string
	 */
	public function index(){
		if($this->session->userdata("logged_in")){
			
			redirect("admin/main");
		}
		if($_POST)
			$this->login ();
		else
			$this->load->view('admin/index');
	}
	
	/**
	 * Login process
	 *
	 * @param       Post data of username/password
	 * @return      string
	 */
	public function login(){
		extract($_POST);
               // print_r($_POST);exit;
		$this->load->model("admin/index_model");
		$result = $this->index_model->login_check($username, $password);
		 //print_r($result);exit;
		if($result == 0){
			$this->session->set_flashdata('login_error_user', TRUE);
			redirect("admin/home");
		}
		else if($result == 1){
			$this->session->set_flashdata('login_error_userandpass', TRUE);
			redirect("admin/home");
		}
		else if($result){
                   // echo 'hiii i am here';exit;
			$this->session->set_userdata(array(
				'logged_in'=>TRUE , 
				'userid' => $result[0]->iId
			));
			redirect(base_url().'admin/main');
		}
	}
	
	/**
	 * Logs out the Admin panel
	 *
	 * @param       ------
	 * @return      string
	 */
	public function logout(){
		
		$unsetdata = array('logged_in','userid');
		//$unsetdata = array('userlogged_in', 'enduserid','username');
		//$this->session->unset_userdata($unsetdatat);
		$this->session->sess_destroy($unsetdata);
		redirect(base_url().'admin/home');
		exit;
	}
        
}