<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if ( ! function_exists('userinfo'))
{
   $ci = '';
   function userinfo() {

         $ci=& get_instance();
         $ci->load->database();

         //$useridfor = $ci->session->userdata("1");
         $useridfor = 1;

        $sql = "SELECT iId, iRoleId, vFirstName, vLastName,vEmailAddress,vProfileImage, (SELECT vRoleName FROM admin_roles WHERE admin_roles.iId = admin_users.iRoleId) as rolename FROM admin_users where iId= ".$useridfor." LIMIT 0,1";
        $query = $ci->db->query($sql);
        $row = $query->result();
        return $row;
}
}

if ( ! function_exists('pluck'))
{

    function pluck ( $a, $prop )
	{
		$out = array();
		for ( $i=0, $len=count($a) ; $i<$len ; $i++ ) {
			$out[] = $a[$i][$prop];
		}
		return $out;
	}

}

if ( ! function_exists('dateformat'))
{

    function dateformat ( $date )
	{
        if($date == '' || $date == 0 || $date == NULL || $date == 'null'){
            return 'N/A';
        }else{
            return date("j M, Y", strtotime($date));
        }

	}

}

if ( ! function_exists('ad_urlgeneratorevent'))
{
	$ci = '';

    function ad_urlgeneratorevent ( $id, $title )
	{

		$changedurl = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', trim($title));
		$changedurl = strtolower(trim($changedurl, '-'));
		$changedurl = preg_replace("/[\/_|+ -]+/", '-', $changedurl);
		$changedurl = base_url()."events/itemdetails/".$id."/".$changedurl.".html";
		return $changedurl;
	}

}

if ( ! function_exists('slideinfo'))
{
   $ci = '';
   function slideinfo() {

         $ci=& get_instance();
         $ci->load->database();

           $ci->load->model('admin/slides_model');
           $allparentlist = $ci->slides_model->all_category_dropdown('1');
           $result_value[] = '';$k = 0;

           foreach($allparentlist as $parent)
            {

                $result_value[$k] = array("iId"=>$parent->iId, "vTitle"=>$parent->vTitle);
                $allchildlist = $ci->categories_model->all_category_dropdown('1');

                foreach($allchildlist as $child)
                {
                    $result_value[$k]['sub'][] = array("iId"=>$child->iId, "vTitle"=>$child->vTitle);
                }

               $k++;
            }

            return $result_value;
}

}

function doPrint_r($data) {

    echo "<pre><br/>";
    print_r($data);
    echo "</pre>";
}
