-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 09, 2019 at 02:18 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 7.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aitadmin`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_roles`
--

CREATE TABLE `admin_roles` (
  `iId` mediumint(7) NOT NULL,
  `vRoleName` varchar(20) NOT NULL,
  `eStatus` enum('y','n') NOT NULL DEFAULT 'y'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_roles`
--

INSERT INTO `admin_roles` (`iId`, `vRoleName`, `eStatus`) VALUES
(1, 'Super Admin', 'y'),
(2, 'Admin', 'y'),
(3, 'Manager', 'y'),
(4, 'Content Writer', 'y'),
(5, 'User', 'y'),
(6, 'Sales Manager', 'y');

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `iId` mediumint(7) NOT NULL,
  `iRoleId` tinyint(2) NOT NULL DEFAULT '5',
  `activation_code` varchar(155) DEFAULT NULL,
  `vFirstName` varchar(20) NOT NULL,
  `vLastName` varchar(20) NOT NULL,
  `eGender` enum('1','2') NOT NULL COMMENT '1 - Male, 2 - Female',
  `vEmailAddress` varchar(100) NOT NULL,
  `vPassword` varchar(30) NOT NULL,
  `vMobile` varchar(15) NOT NULL,
  `vFacebook` varchar(100) NOT NULL,
  `vTwitter` varchar(100) NOT NULL,
  `vLinkedIn` varchar(100) NOT NULL,
  `vGoogleplus` varchar(100) NOT NULL,
  `vCompany` varchar(100) NOT NULL,
  `vAddress` varchar(200) NOT NULL,
  `vProfileImage` varchar(255) NOT NULL,
  `eDealType` enum('1','2','3','4','5','6','7','8') NOT NULL COMMENT '1-Classifieds, 2-Listings, 3-Deals, 4-Coupons, 5-Events, 6-Services, 7-Roommates, 8-Jobs',
  `iCountryId` mediumint(7) NOT NULL,
  `iStateId` int(10) NOT NULL,
  `vCity` varchar(50) NOT NULL,
  `iRegionId` int(10) NOT NULL,
  `vZipCode` varchar(20) NOT NULL,
  `tAboutMe` text NOT NULL,
  `eStatus` enum('y','n','0') NOT NULL DEFAULT 'y',
  `vCreatedBy` varchar(40) NOT NULL,
  `vCreatedOn` date NOT NULL,
  `vUpdatedBy` varchar(40) NOT NULL,
  `vUpdatedOn` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`iId`, `iRoleId`, `activation_code`, `vFirstName`, `vLastName`, `eGender`, `vEmailAddress`, `vPassword`, `vMobile`, `vFacebook`, `vTwitter`, `vLinkedIn`, `vGoogleplus`, `vCompany`, `vAddress`, `vProfileImage`, `eDealType`, `iCountryId`, `iStateId`, `vCity`, `iRegionId`, `vZipCode`, `tAboutMe`, `eStatus`, `vCreatedBy`, `vCreatedOn`, `vUpdatedBy`, `vUpdatedOn`) VALUES
(1, 1, NULL, 'AIT', 'Admin', '1', 'admin@123.com', 'admin', '', '', '', '', '', '', '', '', '', 0, 0, '', 0, '', '', 'y', '', '0000-00-00', '', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `birthday`
--

CREATE TABLE `birthday` (
  `bdid` int(5) NOT NULL,
  `bday_name` varchar(20) NOT NULL,
  `birthdate` date NOT NULL,
  `bdimage` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `birthday`
--

INSERT INTO `birthday` (`bdid`, `bday_name`, `birthdate`, `bdimage`) VALUES
(21, 'Harish Pathare', '2019-05-03', 'Bday-20190503090937.jpg'),
(22, 'Amol Bengle', '2019-05-07', 'Bday-20190506090848.jpg'),
(24, 'Vipul Viswanathan', '2019-05-18', 'Bday-20190508025813.jpg'),
(25, 'Samidha Mamidwar', '2019-05-09', 'Bday-20190508032742.jpg'),
(26, 'Pradnya Patrawale', '2019-05-15', 'Bday-20190514092628.jpg'),
(27, 'Rohit Kshirsagar', '2019-05-28', 'Bday-20190527012852.jpg'),
(29, '11111', '2019-06-04', 'noimage.jpg'),
(30, 'Siddhant Mitra', '2019-06-07', 'Bday-20190607082144.jpg'),
(31, 'Nishtha Mittal', '2019-06-18', 'Bday-20190618092309.jpg'),
(32, 'Tejas Hajare', '2019-06-24', 'Bday-20190624090905.jpg'),
(33, 'Darshit Shah', '2019-06-26', 'Bday-20190625041716.jpg'),
(34, 'Anil Kumar', '2019-07-02', 'Bday-20190701060605.jpg'),
(36, 'Radhika Bhatia', '2019-07-08', 'Bday-20190708120531.jpg'),
(37, 'Ismil Nadaf', '2019-07-12', 'Bday-20190711050623.jpg'),
(38, 'Roopali Srivastava', '2019-07-22', 'Bday-20190719053643.jpg'),
(39, 'Sameer Shinde', '2019-07-24', 'Bday-20190724090157.jpg'),
(40, 'Arun Gawade', '2019-08-01', 'Bday-20190731050806.jpg'),
(41, 'Vikas Jankar', '2019-08-02', 'Bday-20190731050848.jpg'),
(42, 'Shakil Sayed', '2019-08-05', 'Bday-20190805092041.jpg'),
(43, 'Mayuresh Raskar', '2019-08-21', 'Bday-20190820055924.jpg'),
(44, 'Rasika Tiwari', '2019-08-28', 'Bday-20190827104004.jpg'),
(45, 'Shrikant Sonawane', '2019-09-03', 'Bday-20190902022259.jpg'),
(46, 'Chetan Makode', '2019-09-05', 'Bday-20190905101935.jpg'),
(47, 'Rohit Mahale', '2019-09-06', 'Bday-20190905063955.jpg'),
(48, 'Anbalagan Ambur', '2019-09-13', 'Bday-20190910095907.jpg'),
(49, 'Rizwan Ansari', '2019-09-12', 'Bday-20190910100003.jpg'),
(50, 'Swapnil Mahadik', '2019-09-24', 'Bday-20190923055835.jpg'),
(51, 'Shubham Bhopale', '2019-10-08', 'Bday-20191007050220.jpg'),
(52, 'Umesh Govind Dipikar', '2019-10-11', 'Bday-20191010053932.jpg'),
(53, 'Shahid Khan', '2019-10-14', 'Bday-20191014125747.jpg'),
(54, 'Vishal Mane', '2019-10-22', 'Bday-20191021060529.jpg'),
(55, 'Akash Salodkar', '2019-10-24', 'Bday-20191023053906.jpg'),
(56, 'Vinod Talla', '2019-11-12', 'Bday-20191111044426.jpg'),
(57, 'Siddharth Gupta', '2019-11-15', 'Bday-20191115090913.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `iId` smallint(5) NOT NULL,
  `vTitle` varchar(100) NOT NULL,
  `eStatus` enum('0','1','2') NOT NULL DEFAULT '1' COMMENT '1 - Active, 2 - De-active, 0 - Remove',
  `vCreatedBy` varchar(40) NOT NULL,
  `vCreatedOn` date NOT NULL,
  `vUpdatedBy` varchar(40) NOT NULL,
  `vUpdatedOn` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`iId`, `vTitle`, `eStatus`, `vCreatedBy`, `vCreatedOn`, `vUpdatedBy`, `vUpdatedOn`) VALUES
(1, 'Thought of the day', '1', 'Gnanendra', '2018-10-04', 'Gnanendra', '2018-10-04'),
(2, 'Birthday Messages', '1', 'Gnanendra', '2018-10-04', 'Gnanendra', '2018-10-04'),
(3, 'Welcome Messages', '1', 'Gnanendra', '2018-10-04', 'Gnanendra', '2018-10-05'),
(4, 'Special Messages', '1', 'Gnanendra', '2018-10-04', 'Gnanendra', '2018-10-04');

-- --------------------------------------------------------

--
-- Table structure for table `demo`
--

CREATE TABLE `demo` (
  `id` int(5) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `demo`
--

INSERT INTO `demo` (`id`, `firstname`, `lastname`) VALUES
(1, 'chai', 'a'),
(2, 'chai', 'a'),
(3, 'chai', 'a'),
(4, 'mayuresh', 'raskar'),
(5, 'gnanendra', 'chowdhary'),
(6, 'xss', 'chai'),
(7, 'vishal', 'deshmukh');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `EventName` varchar(250) NOT NULL,
  `FromDate` date NOT NULL,
  `ToDate` date NOT NULL,
  `Description` text NOT NULL,
  `isresponsive` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `CreatedBy` varchar(30) NOT NULL,
  `CreatedDate` date DEFAULT NULL,
  `UpdatedDate` date DEFAULT NULL,
  `UpdatedBy` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `EventName`, `FromDate`, `ToDate`, `Description`, `isresponsive`, `status`, `CreatedBy`, `CreatedDate`, `UpdatedDate`, `UpdatedBy`) VALUES
(1, 'Welcome Message', '2018-11-21', '2018-11-30', '<p style="text-align: center; "><span style="font-size: 36px; font-family: Tahoma;"><br></span></p><p style="text-align: center; "><span style="font-size: 36px; font-family: Tahoma;">WELCOME Mr. RAJ SIR</span></p><p style="text-align: center; "><img src="http://192.168.1.113/aitadmin/assets/images/members-of-our-team-enjoyed-celebrating-diwali12.jpg" style="width: 198px;"><span style="font-size: 36px; font-family: Tahoma;"><br></span></p>', 1, 2, 'AIT', '2018-11-23', '2018-11-30', 'AIT'),
(2, 'hello', '2018-11-26', '2018-11-26', '', 0, 0, 'AIT', '2018-11-26', NULL, ''),
(3, 'ISMIL', '2018-11-27', '2018-11-27', '<p style="text-align: center; "><span style="font-size: 36px; font-family: Tahoma;">HAPPY BIRTHDAY ISMIL</span></p><p style="text-align: center; "><span style="font-family: Impact;"><br></span></p><p style="text-align: center; "><img src="http://192.168.1.113/aitadmin/assets/images/Bday-201811230233261.jpg" style="width: 365.453px; height: 365.453px;"><span style="font-family: Impact;"><br></span></p>', 0, 0, 'AIT', '2018-11-27', '2018-11-27', 'AIT'),
(4, 'Client', '2019-04-26', '2019-04-26', '<div style="text-align: center;"><img src="http://192.168.1.244/aitadmin/assets/images/122.png" style="width: 716.609px; height: 398.6px;"><br></div><div style="text-align: center;"></div><div style="text-align: center;"></div>', 0, 1, 'AIT', '2019-04-12', '2019-04-26', 'AIT'),
(5, 'New Clients', '2019-05-15', '2019-05-17', '<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<img src="http://192.168.1.244/aitadmin/assets/images/client-visit-design-01_(2).jpg" style="width: 786px;"><br></p>', 1, 1, 'AIT', '2019-05-15', '2019-05-15', 'AIT'),
(6, 'NewsLetter March - April 2019 -- Page 1', '2019-05-28', '2019-07-31', '<p>&nbsp; &nbsp; &nbsp;&nbsp;<img src="http://192.168.1.244/aitadmin/assets/images/11.png" style="width: 773px; float: none;"><br></p>', 1, 2, 'AIT', '2019-05-28', '2019-06-18', 'AIT'),
(7, '	NewsLetter March - April 2019 -- Page 2', '2019-05-28', '2019-05-31', '<p><img src="http://192.168.1.244/aitadmin/assets/images/2.png" style="width: 795px;"><br></p>', 1, 2, 'AIT', '2019-05-28', NULL, ''),
(8, '	NewsLetter March - April 2019 -- Page 3', '2019-05-28', '2019-07-31', '<p><img src="http://192.168.1.244/aitadmin/assets/images/3.png" style="width: 765px;"><br></p>', 1, 2, 'AIT', '2019-05-28', '2019-06-18', 'AIT'),
(9, '	NewsLetter March - April 2019 -- Page 4', '2019-05-28', '2019-07-31', '<p>&nbsp;&nbsp;<img src="http://192.168.1.244/aitadmin/assets/images/4.png" style="width: 727px;"><br></p>', 1, 2, 'AIT', '2019-05-28', '2019-06-18', 'AIT'),
(10, '	NewsLetter March - April 2019 -- Page 5', '2019-05-28', '2019-07-31', '<p><img src="http://192.168.1.244/aitadmin/assets/images/51.png" style="width: 791px;"><br></p>', 1, 2, 'AIT', '2019-05-28', '2019-06-18', 'AIT'),
(11, '	NewsLetter March - April 2019 -- Page 6', '2019-05-28', '2019-07-31', '<p><img src="http://192.168.1.244/aitadmin/assets/images/6.png" style="width: 740px;"><br></p>', 1, 2, 'AIT', '2019-05-28', '2019-06-18', 'AIT'),
(12, 'NewsLetter March - April 2019 -- Page 7', '2019-05-28', '2019-07-31', '<p><img src="http://192.168.1.244/aitadmin/assets/images/7.png" style="width: 728px;"><br></p>', 1, 2, 'AIT', '2019-05-28', '2019-06-18', 'AIT'),
(13, '	NewsLetter March - April 2019 -- Page 8', '2019-05-28', '2019-07-31', '<p>&nbsp; &nbsp;<img src="http://192.168.1.244/aitadmin/assets/images/8.png" style="width: 670px;"><br></p>', 1, 2, 'AIT', '2019-05-28', '2019-06-18', 'AIT'),
(14, '	NewsLetter March - April 2019 -- Page 9', '2019-05-28', '2019-07-31', '<p><img src="http://192.168.1.244/aitadmin/assets/images/9.png" style="width: 648px;"><br></p>', 1, 2, 'AIT', '2019-05-28', '2019-06-18', 'AIT'),
(15, '	NewsLetter March - April 2019 -- Page 10', '2019-05-28', '2019-07-31', '<p><img src="http://192.168.1.244/aitadmin/assets/images/10.png" style="width: 753px;"><br></p>', 1, 2, 'AIT', '2019-05-28', '2019-06-18', 'AIT'),
(16, '	NewsLetter March - April 2019 -- Page 11', '2019-05-28', '2019-07-31', '<p><img src="http://192.168.1.244/aitadmin/assets/images/111.png" style="width: 629px;"><br></p>', 1, 2, 'AIT', '2019-05-28', '2019-06-18', 'AIT'),
(17, '	NewsLetter March - April 2019 -- Page 12', '2019-05-28', '2019-07-31', '<p><img src="http://192.168.1.244/aitadmin/assets/images/12.png" style="width: 680px;"><br></p>', 1, 2, 'AIT', '2019-05-28', '2019-06-18', 'AIT'),
(18, 'NewsLetter March - April 2019 -- Page 13', '2019-05-28', '2019-07-31', '<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<img src="http://192.168.1.244/aitadmin/assets/images/13.png" style="width: 436.324px; height: 544px;"><br></p>', 0, 2, 'AIT', '2019-05-28', '2019-06-18', 'AIT'),
(19, 'Thought of the Day', '2019-05-30', '2019-05-30', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190530022505.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-05-30', '2019-05-30', 'AIT'),
(20, 'Thought of the Day', '2019-05-31', '2019-05-31', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190531074924.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-05-31', '2019-05-31', 'AIT'),
(21, 'Thought of the Day', '2019-06-03', '2019-06-03', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190603071636.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-06-03', '2019-06-03', 'AIT'),
(26, 'Thought of the Day', '2019-06-04', '2019-06-04', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190604102328.jpg" style="width: 862px;"><br></p>', 1, 2, 'AIT', '2019-06-04', '2019-06-04', 'AIT'),
(27, 'Thought of the Day', '2019-06-04', '2019-06-04', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190604102328.jpg" style="width: 862px;"><br></p>', 1, 2, 'AIT', '2019-06-04', '2019-06-04', 'AIT'),
(28, 'Thought of the Day', '2019-06-06', '2019-06-06', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190606075151.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-06-06', '2019-06-06', 'AIT'),
(29, 'Thought of the Day', '2019-06-06', '2019-06-06', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190606075152.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-06-06', '2019-06-06', 'AIT'),
(30, 'Thought of the Day', '2019-06-07', '2019-06-07', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190607073526.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-06-07', '2019-06-07', 'AIT'),
(31, 'Thought of the Day', '2019-06-10', '2019-06-10', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190610082425.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-06-10', '2019-06-10', 'AIT'),
(32, 'Thought of the Day', '2019-06-11', '2019-06-11', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190611080947.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-06-11', '2019-06-11', 'AIT'),
(33, 'Thought of the Day', '2019-06-13', '2019-06-13', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190613102625.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-06-13', '2019-06-13', 'AIT'),
(34, 'Thought of the Day', '2019-06-17', '2019-06-17', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190617071958.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-06-17', '2019-06-17', 'AIT'),
(35, 'Thought of the Day', '2019-06-21', '2019-06-21', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190621074007.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-06-21', '2019-06-21', 'AIT'),
(36, 'Thought of the Day', '2019-06-24', '2019-06-24', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190624074549.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-06-24', '2019-06-24', 'AIT'),
(37, 'Thought of the Day', '2019-06-25', '2019-06-25', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190625072118.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-06-25', '2019-06-25', 'AIT'),
(38, 'Thought of the Day', '2019-06-25', '2019-06-25', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190625072118.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-06-25', '2019-06-25', 'AIT'),
(39, 'Thought of the Day', '2019-06-26', '2019-06-26', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190626072322.jpg" style="width: 50%;"><br></p>', 1, 1, 'AIT', '2019-06-26', '2019-06-26', 'AIT'),
(40, 'Client Visit', '2019-06-27', '2019-07-02', '<p style="text-align: center; "><b style="color: rgb(34, 34, 34); font-family: Arial, Helvetica, sans-serif; font-size: small;"><span style="font-size: 24px;">Client Visit</span></b></p><p style="text-align: center; "><img src="http://192.168.1.244/aitadmin/assets/images/HC_(1).png" style="width: 634.5px; height: 356.998px;"><b style="color: rgb(34, 34, 34); font-family: Arial, Helvetica, sans-serif; font-size: small;"><span style="font-size: 24px;"><br></span></b><br></p>', 1, 1, 'AIT', '2019-06-27', NULL, ''),
(41, 'Client Visit ', '2019-06-27', '2019-07-02', '<p style="text-align: center; "><b><span style="font-size: 36px;">Client Visit</span></b></p><p style="text-align: center; "><img src="http://192.168.1.244/aitadmin/assets/images/SM.png" style="width: 543.86px; height: 306px;"><b><span style="font-size: 36px;"><br></span></b></p>', 1, 1, 'AIT', '2019-06-27', NULL, ''),
(42, 'Thought of the Day', '2019-06-28', '2019-06-28', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190628074257.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-06-28', '2019-06-28', 'AIT'),
(43, 'Mulesoft Meetup', '2019-06-28', '2019-06-30', '<p style="text-align: center; "><img src="http://192.168.1.244/aitadmin/assets/images/slider_admin_window.jpg" style="width: 599.25px; height: 466.083px;"><br></p>', 1, 1, 'AIT', '2019-06-28', '2019-06-28', 'AIT'),
(44, 'Thought of the Day', '2019-07-01', '2019-07-01', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190701082246.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-07-01', '2019-07-01', 'AIT'),
(45, 'Thought of the Day', '2019-07-03', '2019-07-03', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190703075121.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-07-03', '2019-07-03', 'AIT'),
(46, 'Thought of the Day', '2019-07-04', '2019-07-04', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190704080601.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-07-04', '2019-07-04', 'AIT'),
(47, 'Thought of the Day', '2019-07-08', '2019-07-08', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190708074808.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-07-08', '2019-07-08', 'AIT'),
(48, 'Thought of the Day', '2019-07-09', '2019-07-09', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190709072652.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-07-09', '2019-07-09', 'AIT'),
(49, 'Thought of the Day', '2019-07-10', '2019-07-10', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190710070505.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-07-10', '2019-07-10', 'AIT'),
(50, 'Thought of the Day', '2019-07-11', '2019-07-11', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190711090651.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-07-11', '2019-07-11', 'AIT'),
(51, 'Thought of the Day', '2019-07-12', '2019-07-12', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190712074629.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-07-12', '2019-07-12', 'AIT'),
(52, 'Thought of the Day', '2019-07-15', '2019-07-15', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190715070944.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-07-15', '2019-07-15', 'AIT'),
(53, 'Thought of the Day', '2019-07-16', '2019-07-16', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190716071538.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-07-16', '2019-07-16', 'AIT'),
(54, 'Raj Sir Bday', '2019-07-16', '2019-07-16', '<p style="text-align: center; "><br></p><p style="text-align: center; "><img src="http://192.168.1.244/aitadmin/assets/images/image003.jpg" style="width: 550.5px; height: 429.799px;"><br></p>', 1, 1, 'AIT', '2019-07-16', '2019-07-16', 'AIT'),
(55, 'RajSir Bday Desc', '2019-07-16', '2019-07-16', '<p style="text-align: center; "><br></p><p style="text-align: center; "><img src="http://192.168.1.244/aitadmin/assets/images/image004.jpg" style="width: 517.5px; height: 404.635px;"><br></p>', 1, 1, 'AIT', '2019-07-16', '2019-07-16', 'AIT'),
(56, 'Thought of the Day', '2019-07-17', '2019-07-17', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190717071858.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-07-17', '2019-07-17', 'AIT'),
(57, 'Thought of the Day', '2019-07-18', '2019-07-18', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190718074340.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-07-18', '2019-07-18', 'AIT'),
(58, 'Thought of the Day', '2019-07-19', '2019-07-19', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190719083426.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-07-19', '2019-07-19', 'AIT'),
(59, 'Thought of the Day', '2019-07-19', '2019-07-19', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190719083428.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-07-19', '2019-07-19', 'AIT'),
(60, 'Thought of the Day', '2019-07-22', '2019-07-22', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190722075058.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-07-22', '2019-07-22', 'AIT'),
(61, 'Thought of the Day', '2019-07-23', '2019-07-23', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190723090108.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-07-23', '2019-07-23', 'AIT'),
(62, 'Thought of the Day', '2019-07-24', '2019-07-24', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190724074006.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-07-24', '2019-07-24', 'AIT'),
(63, 'Thought of the Day', '2019-07-25', '2019-07-25', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190725074130.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-07-25', '2019-07-25', 'AIT'),
(64, 'Thought of the Day', '2019-07-26', '2019-07-26', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190726102550.jpg" style="width: 862px;"><br></p>', 1, 0, 'AIT', '2019-07-26', '2019-07-26', 'AIT'),
(65, 'Thought of the Day', '2019-07-26', '2019-07-26', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190726102550.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-07-26', '2019-07-26', 'AIT'),
(66, 'Thought of the Day', '2019-07-29', '2019-07-29', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190729090347.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-07-29', '2019-07-29', 'AIT'),
(67, 'Thought of the Day', '2019-07-30', '2019-07-30', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190730072641.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-07-30', '2019-07-30', 'AIT'),
(68, 'Thought of the Day', '2019-07-31', '2019-07-31', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190731072554.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-07-31', '2019-07-31', 'AIT'),
(69, 'Thought of the Day', '2019-08-01', '2019-08-01', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190801074541.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-08-01', '2019-08-01', 'AIT'),
(70, 'Thought of the Day', '2019-08-02', '2019-08-02', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190802072729.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-08-02', '2019-08-02', 'AIT'),
(71, 'Thought of the Day', '2019-08-05', '2019-08-05', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190805073042.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-08-05', '2019-08-05', 'AIT'),
(72, 'Thought of the Day', '2019-08-05', '2019-08-05', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190805073042.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-08-05', '2019-08-05', 'AIT'),
(73, 'Bday', '2019-08-05', '2019-08-05', '<p style="text-align: center; "><span style="font-size: 36px;"><b>Happy Birthday</b></span></p><p style="text-align: center; "><img src="http://192.168.1.244/aitadmin/assets/images/Emp-234.jpg" style="width: 154.5px; height: 192px;"><span style="font-size: 36px;"><b><br></b></span></p><p style="text-align: center; "><span style="font-size: 36px;"><b>Prabhakar Kumar</b></span></p>', 1, 1, 'AIT', '2019-08-05', NULL, ''),
(74, 'Thought of the Day', '2019-08-06', '2019-08-06', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190806073356.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-08-06', '2019-08-06', 'AIT'),
(75, 'Thought of the Day', '2019-08-07', '2019-08-07', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190807064212.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-08-07', '2019-08-07', 'AIT'),
(76, 'Blood Donation Camp', '2019-08-07', '2019-08-13', '<p style="text-align: center; "><br></p><p style="text-align: center; "><img src="http://192.168.1.244/aitadmin/assets/images/image0013.jpg" style="width: 546.42px; height: 374px;"><br>\r\n<br class="Apple-interchange-newline"></p>', 1, 1, 'AIT', '2019-08-07', '2019-08-07', 'AIT'),
(77, 'Thought of the Day', '2019-08-08', '2019-08-08', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190808070655.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-08-08', '2019-08-08', 'AIT'),
(78, 'Thought of the Day', '2019-08-09', '2019-08-09', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190809073530.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-08-09', '2019-08-09', 'AIT'),
(79, 'Thought of the Day', '2019-08-12', '2019-08-12', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190812010641.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-08-12', '2019-08-12', 'AIT'),
(80, 'Thought of the Day', '2019-08-13', '2019-08-13', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190813062809.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-08-13', '2019-08-13', 'AIT'),
(81, 'Thought of the Day', '2019-08-14', '2019-08-14', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190814082441.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-08-14', '2019-08-14', 'AIT'),
(82, 'Thought of the Day', '2019-08-16', '2019-08-16', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190816075057.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-08-16', '2019-08-16', 'AIT'),
(83, 'Thought of the Day', '2019-08-19', '2019-08-19', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190819071618.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-08-19', '2019-08-19', 'AIT'),
(84, 'Thought of the Day', '2019-08-20', '2019-08-20', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190820073204.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-08-20', '2019-08-20', 'AIT'),
(85, 'Thought of the Day', '2019-08-21', '2019-08-21', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190821071618.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-08-21', '2019-08-21', 'AIT'),
(86, 'Thought of the Day', '2019-08-21', '2019-08-21', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190821071620.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-08-21', '2019-08-21', 'AIT'),
(87, 'Thought of the Day', '2019-08-22', '2019-08-22', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190822073857.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-08-22', '2019-08-22', 'AIT'),
(88, 'Thought of the Day', '2019-08-23', '2019-08-23', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190823071447.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-08-23', '2019-08-23', 'AIT'),
(89, 'Thought of the Day', '2019-08-27', '2019-08-27', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190827081029.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-08-27', '2019-08-27', 'AIT'),
(90, 'Thought of the Day', '2019-08-28', '2019-08-28', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190828081912.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-08-28', '2019-08-28', 'AIT'),
(91, 'Thought of the Day', '2019-08-28', '2019-08-28', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190828081913.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-08-28', '2019-08-28', 'AIT'),
(92, 'Thought of the Day', '2019-08-29', '2019-08-29', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190829084303.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-08-29', '2019-08-29', 'AIT'),
(93, 'Thought of the Day', '2019-08-30', '2019-08-30', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190830082610.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-08-30', '2019-08-30', 'AIT'),
(94, 'Thought of the Day', '2019-09-02', '2019-09-02', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190902072105.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-09-02', '2019-09-02', 'AIT'),
(95, 'Thought of the Day', '2019-09-03', '2019-09-03', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190903075611.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-09-03', '2019-09-03', 'AIT'),
(96, 'Thought of the Day', '2019-09-04', '2019-09-04', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190904075001.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-09-04', '2019-09-04', 'AIT'),
(97, 'Thought of the Day', '2019-09-05', '2019-09-05', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190905080342.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-09-05', '2019-09-05', 'AIT'),
(98, 'Thought of the Day', '2019-09-06', '2019-09-06', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190906105858.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-09-06', '2019-09-06', 'AIT'),
(99, 'Thought of the Day', '2019-09-09', '2019-09-09', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190909071515.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-09-09', '2019-09-09', 'AIT'),
(100, 'Thought of the Day', '2019-09-10', '2019-09-10', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190910072152.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-09-10', '2019-09-10', 'AIT'),
(101, 'Thought of the Day', '2019-09-11', '2019-09-11', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190911071725.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-09-11', '2019-09-11', 'AIT'),
(102, 'Thought of the Day', '2019-09-13', '2019-09-13', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190913071942.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-09-13', '2019-09-13', 'AIT'),
(103, 'Thought of the Day', '2019-09-16', '2019-09-16', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190916071110.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-09-16', '2019-09-16', 'AIT'),
(104, 'Thought of the Day', '2019-09-17', '2019-09-17', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190917071935.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-09-17', '2019-09-17', 'AIT'),
(105, 'Thought of the Day', '2019-09-18', '2019-09-18', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190918072106.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-09-18', '2019-09-18', 'AIT'),
(106, 'Thought of the Day', '2019-09-19', '2019-09-19', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190919080321.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-09-19', '2019-09-19', 'AIT'),
(107, 'Thought of the Day', '2019-09-20', '2019-09-20', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190920084956.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-09-20', '2019-09-20', 'AIT'),
(108, 'Thought of the Day', '2019-09-23', '2019-09-23', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190923090050.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-09-23', '2019-09-23', 'AIT'),
(109, 'Thought of the Day', '2019-09-23', '2019-09-23', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190923090056.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-09-23', '2019-09-23', 'AIT'),
(110, 'Thought of the Day', '2019-09-24', '2019-09-24', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190924080445.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-09-24', '2019-09-24', 'AIT'),
(111, 'Thought of the Day', '2019-09-25', '2019-09-25', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190925074015.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-09-25', '2019-09-25', 'AIT'),
(112, 'Thought of the Day', '2019-09-26', '2019-09-26', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190926075536.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-09-26', '2019-09-26', 'AIT'),
(113, 'Thought of the Day', '2019-09-27', '2019-09-27', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190927081102.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-09-27', '2019-09-27', 'AIT'),
(114, 'Thought of the Day', '2019-09-30', '2019-09-30', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20190930071105.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-09-30', '2019-09-30', 'AIT'),
(115, 'Thought of the Day', '2019-10-01', '2019-10-01', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191001070649.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-10-01', '2019-10-01', 'AIT'),
(116, 'Thought of the Day', '2019-10-03', '2019-10-03', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191003080249.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-10-03', '2019-10-03', 'AIT'),
(117, 'Thought of the Day', '2019-10-04', '2019-10-04', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191004075102.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-10-04', '2019-10-04', 'AIT'),
(118, 'Thought of the Day', '2019-10-07', '2019-10-07', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191007081216.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-10-07', '2019-10-07', 'AIT'),
(119, 'Thought of the Day', '2019-10-08', '2019-10-08', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191008080200.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-10-08', '2019-10-08', 'AIT'),
(120, 'Thought of the Day', '2019-10-09', '2019-10-09', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191009082350.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-10-09', '2019-10-09', 'AIT'),
(121, 'Thought of the Day', '2019-10-10', '2019-10-10', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191010080042.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-10-10', '2019-10-10', 'AIT'),
(122, 'Thought of the Day', '2019-10-10', '2019-10-10', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191010080043.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-10-10', '2019-10-10', 'AIT'),
(123, 'Thought of the Day', '2019-10-11', '2019-10-11', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191011082335.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-10-11', '2019-10-11', 'AIT'),
(124, 'Thought of the Day', '2019-10-14', '2019-10-14', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191014075402.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-10-14', '2019-10-14', 'AIT'),
(125, 'Thought of the Day', '2019-10-15', '2019-10-15', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191015081648.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-10-15', '2019-10-15', 'AIT'),
(126, 'Thought of the Day', '2019-10-16', '2019-10-16', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191016081336.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-10-16', '2019-10-16', 'AIT'),
(127, 'Thought of the Day', '2019-10-17', '2019-10-17', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191017080535.jpg" style="width: 862px;"><br></p>', 1, 0, 'AIT', '2019-10-17', '2019-10-17', 'AIT'),
(128, 'Thought of the Day', '2019-10-17', '2019-10-17', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191017080535.jpg" style="width: 862px;"><br></p>', 1, 0, 'AIT', '2019-10-17', '2019-10-17', 'AIT'),
(129, 'Thought Of The Day', '2019-10-17', '2019-10-17', '<p style="text-align: center; "><img src="http://192.168.1.244/aitadmin/assets/images/yh.jpg" style="width: 550px; float: none;" class=""><br></p>', 1, 1, 'AIT', '2019-10-17', NULL, ''),
(130, 'Thought of the Day', '2019-10-18', '2019-10-18', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191018082323.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-10-18', '2019-10-18', 'AIT'),
(131, 'Thought of the Day', '2019-10-18', '2019-10-18', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191018082323.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-10-18', '2019-10-18', 'AIT'),
(132, 'Thought of the Day', '2019-10-21', '2019-10-21', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191021075359.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-10-21', '2019-10-21', 'AIT'),
(133, 'Thought of the Day', '2019-10-22', '2019-10-22', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191022072142.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-10-22', '2019-10-22', 'AIT'),
(134, 'Diwali 2019', '2019-10-22', '2019-10-30', '<p style="text-align: center; "><img src="http://192.168.1.244/aitadmin/assets/images/diwali_greeting_20191.jpg" style="width: 100%;"><br></p>', 0, 1, 'AIT', '2019-10-22', '2019-10-22', 'AIT'),
(135, 'Thought of the Day', '2019-10-23', '2019-10-23', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191023075534.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-10-23', '2019-10-23', 'AIT'),
(136, 'Thought of the Day', '2019-10-24', '2019-10-24', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191024072057.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-10-24', '2019-10-24', 'AIT'),
(137, 'Thought of the Day', '2019-10-30', '2019-10-30', '<p style="text-align: center;">&nbsp;<img src="http://192.168.1.244/aitadmin/assets/images/20191030075711.jpg" style="width: 442.469px; float: none; height: 331.852px;"><br></p>', 1, 1, 'AIT', '2019-10-30', '2019-10-30', 'AIT'),
(138, 'Thought of the Day', '2019-10-30', '2019-10-30', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191030075713.jpg" style="width: 862px;"><br></p>', 1, 0, 'AIT', '2019-10-30', '2019-10-30', 'AIT'),
(139, 'Thought of the Day', '2019-10-30', '2019-10-30', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191030075713.jpg" style="width: 862px;"><br></p>', 1, 0, 'AIT', '2019-10-30', '2019-10-30', 'AIT'),
(140, 'Thought of the Day', '2019-10-30', '2019-10-30', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191030075713.jpg" style="width: 862px;"><br></p>', 1, 0, 'AIT', '2019-10-30', '2019-10-30', 'AIT'),
(141, 'Thought of the Day', '2019-10-30', '2019-10-30', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191030075713.jpg" style="width: 862px;"><br></p>', 1, 0, 'AIT', '2019-10-30', '2019-10-30', 'AIT'),
(142, 'Thought of the Day', '2019-10-31', '2019-10-31', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191031053443.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-10-31', '2019-10-31', 'AIT'),
(143, 'Thought of the Day', '2019-11-01', '2019-11-01', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191101063348.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-11-01', '2019-11-01', 'AIT'),
(144, 'Thought of the Day', '2019-11-04', '2019-11-04', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191104063201.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-11-04', '2019-11-04', 'AIT'),
(145, 'Thought of the Day', '2019-11-05', '2019-11-05', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191105064220.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-11-05', '2019-11-05', 'AIT'),
(146, 'Thought of the Day', '2019-11-06', '2019-11-06', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191106060134.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-11-06', '2019-11-06', 'AIT'),
(147, 'Thought of the Day', '2019-11-07', '2019-11-07', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191107070211.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-11-07', '2019-11-07', 'AIT'),
(148, 'Thought of the Day', '2019-11-08', '2019-11-08', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191108070245.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-11-08', '2019-11-08', 'AIT'),
(149, 'Thought of the Day', '2019-11-11', '2019-11-11', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191111053218.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-11-11', '2019-11-11', 'AIT'),
(150, 'Thought of the Day', '2019-11-12', '2019-11-12', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191112070534.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-11-12', '2019-11-12', 'AIT'),
(151, 'Thought of the Day', '2019-11-13', '2019-11-13', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191113070605.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-11-13', '2019-11-13', 'AIT'),
(152, 'Thought of the Day', '2019-11-14', '2019-11-14', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191114064853.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-11-14', '2019-11-14', 'AIT'),
(153, 'Thought of the Day', '2019-11-15', '2019-11-15', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191115050751.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-11-15', '2019-11-15', 'AIT'),
(154, 'Thought of the Day', '2019-11-18', '2019-11-18', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191118065609.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-11-18', '2019-11-18', 'AIT'),
(155, 'Thought of the Day', '2019-11-19', '2019-11-19', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191119064636.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-11-19', '2019-11-19', 'AIT'),
(156, 'Thought of the Day', '2019-11-20', '2019-11-20', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191120064947.jpg" style="width: 862px;"><br></p>', 1, 0, 'AIT', '2019-11-20', '2019-11-20', 'AIT'),
(157, 'Thought of the Day', '2019-11-20', '2019-11-20', '<div style="text-align: center;"><br></div><p><img src="http://192.168.1.244/aitadmin/assets/images/thoght.jpg" style="width: 809px;"><br></p><p><br></p>', 1, 1, 'AIT', '2019-11-20', '2019-11-20', 'AIT'),
(158, 'Thought', '2019-11-21', '2019-11-21', '<p style="text-align: justify;"><b style="color: rgb(34, 34, 34); font-family: Arial, Helvetica, sans-serif; font-size: small; text-align: center;"><i><span style="font-size: 18pt; font-family: Cambria, serif; color: rgb(29, 28, 29); background: rgb(248, 248, 248);"><br></span></i></b></p><p style="text-align: justify;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<b style="color: rgb(34, 34, 34); font-family: Arial, Helvetica, sans-serif; font-size: small; text-align: center;"><i><span style="font-size: 18pt; font-family: Cambria, serif; color: rgb(29, 28, 29); background: rgb(248, 248, 248);">“Lack of direction , not lack of time is the problem. We all have twenty four hours in a day.”</span></i></b><br></p>', 1, 1, 'AIT', '2019-11-21', '2019-11-21', 'AIT'),
(159, 'Thought of the Day', '2019-11-22', '2019-11-22', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191122084904.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-11-22', '2019-11-22', 'AIT'),
(160, 'Thought of the Day', '2019-11-25', '2019-11-25', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191125065424.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-11-25', '2019-11-25', 'AIT'),
(161, 'Thought of the Day', '2019-11-26', '2019-11-26', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191126052416.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-11-26', '2019-11-26', 'AIT'),
(162, 'Thought of the Day', '2019-11-27', '2019-11-27', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191127065711.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-11-27', '2019-11-27', 'AIT'),
(163, 'Thought of the Day', '2019-11-28', '2019-11-28', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191128062645.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-11-28', '2019-11-28', 'AIT'),
(164, 'Thought of the Day', '2019-11-28', '2019-11-28', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191128062652.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-11-28', '2019-11-28', 'AIT'),
(165, 'Thought of the Day', '2019-11-29', '2019-11-29', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191129065938.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-11-29', '2019-11-29', 'AIT'),
(166, 'Thought of the Day', '2019-11-29', '2019-11-29', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191129065939.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-11-29', '2019-11-29', 'AIT'),
(167, 'Thought of the Day', '2019-12-02', '2019-12-02', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191202051254.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-12-02', '2019-12-02', 'AIT'),
(168, 'Thought of the Day', '2019-12-03', '2019-12-03', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191203070926.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-12-03', '2019-12-03', 'AIT'),
(169, 'Thought of the Day', '2019-12-04', '2019-12-04', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191204061301.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-12-04', '2019-12-04', 'AIT'),
(170, 'Thought of the Day', '2019-12-05', '2019-12-05', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191205052255.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-12-05', '2019-12-05', 'AIT'),
(171, 'Thought of the Day', '2019-12-06', '2019-12-06', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191206070740.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-12-06', '2019-12-06', 'AIT'),
(172, 'Thought of the Day', '2019-12-09', '2019-12-09', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/20191209070245.jpg" style="width: 862px;"><br></p>', 1, 1, 'AIT', '2019-12-09', '2019-12-09', 'AIT');

-- --------------------------------------------------------

--
-- Table structure for table `masking`
--

CREATE TABLE `masking` (
  `id` int(5) NOT NULL,
  `phone` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `masking`
--

INSERT INTO `masking` (`id`, `phone`) VALUES
(1, 123456789),
(2, 987654321);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(5) NOT NULL,
  `image_status` int(3) NOT NULL,
  `time_interval` int(5) NOT NULL,
  `font_size` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `image_status`, `time_interval`, `font_size`) VALUES
(1, 0, 1000, 50);

-- --------------------------------------------------------

--
-- Table structure for table `slides`
--

CREATE TABLE `slides` (
  `id` int(11) NOT NULL,
  `title` varchar(55) NOT NULL,
  `description` text NOT NULL,
  `image_upload` varchar(500) NOT NULL,
  `isresponsive` int(11) NOT NULL,
  `status` varchar(30) NOT NULL,
  `created_date` date NOT NULL,
  `created_by` varchar(30) NOT NULL,
  `updated_date` date NOT NULL,
  `updated_by` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `slides`
--

INSERT INTO `slides` (`id`, `title`, `description`, `image_upload`, `isresponsive`, `status`, `created_date`, `created_by`, `updated_date`, `updated_by`) VALUES
(1, 'Welcome Message', '<p style="text-align: center; "><span style="font-size: 36px;"><b>Quick Facts</b></span></p><p style="text-align: center; "><img src="http://192.168.1.244/aitadmin/assets/images/quick_facts.JPG" style="width: 809px;"><span style="font-size: 36px;"><b><br></b></span></p><p style="text-align: center; "></p>', '', 0, '1', '2018-11-30', 'AIT', '2019-11-22', 'AIT'),
(2, 'Mule Soft Meetup', '<p style="text-align: center; "><img src="http://192.168.1.244/aitadmin/assets/images/slider_admin_window1.jpg" style="width: 581.848px; float: none; height: 452.976px;"><br></p>', '', 0, '2', '2019-06-28', 'AIT', '2019-06-28', 'AIT'),
(3, 'Thought Of The Day', '<p style="text-align: center;"><span style="font-size: 36px;"><b>Thought Of The Day</b></span><span style="font-size: 14px;">﻿</span></p><p style="text-align: center;"><span style="font-size: 14px;"><br></span></p><h3 align="center" style="margin-right: 0in; margin-left: 0in; font-size: 13.5pt; font-family: Calibri, sans-serif; color: rgb(34, 34, 34); margin-bottom: 7.5pt; text-align: center; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><p class="MsoNormal" align="center" style="margin-right: 0in; margin-bottom: 7.5pt; margin-left: 0in; font-family: Arial, Helvetica, sans-serif; font-size: small; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><span style="font-size: 36px; font-family: Cambria, serif; color: rgb(51, 51, 51);">“Before you are a leader, success is all about growing yourself.</span></p><p class="MsoNormal" align="center" style="margin-right: 0in; margin-bottom: 7.5pt; margin-left: 0in; font-family: Arial, Helvetica, sans-serif; font-size: small; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><span style="font-size: 36px; font-family: Cambria, serif; color: rgb(51, 51, 51);"> When you become a leader, success is all about growing others.”</span></p><p class="MsoNormal" align="center" style="margin-right: 0in; margin-bottom: 7.5pt; margin-left: 0in; font-family: Arial, Helvetica, sans-serif; font-size: small; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><span style="font-size: 36px; font-family: Cambria, serif; color: rgb(51, 51, 51);">– Jack Welch</span></p></h3><p style="text-align: center;"></p>', '', 1, '0', '2018-11-30', 'AIT', '2019-07-02', 'AIT'),
(4, 'Welcome Message', '<p style="text-align: center; "><span style="font-size: 36px;"><br></span></p><p style="text-align: center; "><span style="font-size: 72px;"><b>Welcome AIT Global</b></span></p><p style="text-align: center; "><img src="http://192.168.1.113/aitadmin/assets/images/image22.jpg" style="width: 1099px;"><span style="font-size: 36px;"><br></span></p>', '', 1, '0', '2018-11-30', 'AIT', '2019-04-26', 'AIT'),
(5, 'Journey', '<p style="text-align: center; "><img src="http://192.168.1.244/aitadmin/assets/images/admin_window4.jpg" style="width: 862px;"><br></p>', '', 0, '1', '2019-05-14', 'AIT', '2019-10-31', 'AIT'),
(6, 'Clients', '<div style="text-align: center;"><span style="font-size: 36px;"><b>Our Major Clients&nbsp;</b></span></div><div style="text-align: center;"><img src="http://192.168.1.244/aitadmin/assets/images/client_logo_admin_window3.jpg" style="width: 482.5px; height: 368.872px;"><span style="font-size: 36px;"><b><br></b></span></div>', '', 1, '1', '2019-05-14', 'AIT', '2019-09-02', 'AIT'),
(7, 'Ait Core values', '<p style="text-align: center; "><span style="font-size: 24px;"><b>Our Core Values</b></span></p><p style="text-align: center; "><iframe frameborder="0" src="//www.youtube.com/embed/gWjofpeBUU4" width="640" height="360" class="note-video-clip"></iframe><span style="font-size: 24px;"><b><br></b></span></p>', '', 1, '0', '2019-05-14', 'AIT', '2019-05-14', 'AIT'),
(8, 'eddsdds', '<p><iframe frameborder="0" src="//www.youtube.com/embed/OK_JCtrrv-c" width="640" height="360" class="note-video-clip"></iframe><br></p>', '', 1, '0', '2019-05-14', 'AIT', '2019-05-14', 'AIT'),
(9, 'Partners', '<p style="text-align: center; "><span style="font-size: 36px;"><b>Our Partners</b></span></p><p style="text-align: center; "><img src="http://192.168.1.244/aitadmin/assets/images/company_partner_admin_window_(1).jpg" style="width: 622px; height: 282.858px;"><span style="font-size: 36px;"><b><br></b></span></p><p><br></p>', '', 1, '1', '2019-05-14', 'AIT', '2019-06-27', 'AIT'),
(10, 'Mission', '<p style="text-align: center; "><br></p><p style="text-align: center; "><img src="http://192.168.1.244/aitadmin/assets/images/Vision-edited-012.jpg" style="width: 737.102px; height: 360px;"><br></p><p style="text-align: center; "><br></p>', '', 1, '1', '2019-05-15', 'AIT', '2019-07-23', 'AIT'),
(11, 'Vision', '<p style="text-align: center; "><br></p><p style="text-align: center; "><img src="http://192.168.1.244/aitadmin/assets/images/mission-edited-023.jpg" style="width: 703px; height: 343.345px;"><br></p><p style="text-align: center; "><br></p>', '', 1, '1', '2019-05-15', 'AIT', '2019-07-23', 'AIT'),
(12, 'Core Values', '<p><br></p><p><img src="http://192.168.1.244/aitadmin/assets/images/grow.png" style="width: 862px;"><br></p>', '', 1, '1', '2019-05-15', 'AIT', '2019-05-15', 'AIT'),
(13, 'Our Clients', '<p style="text-align: center; "><span style="font-size: 36px;"><b>Our Clients</b></span></p><p style="text-align: center; "><img src="http://192.168.1.244/aitadmin/assets/images/201811221229462.jpg" style="width: 50%;"><span style="font-size: 36px;"><br></span><br></p>', '', 1, '2', '2018-11-30', 'AIT', '2019-04-26', 'AIT'),
(14, 'Services We Offer', '<p style="text-align: center; "><b><span style="font-size: 48px;">&nbsp; &nbsp;Services We Offer</span><span style="font-size: 48px;">﻿</span></b></p><p style="text-align: center; "><img src="http://192.168.1.244/aitadmin/assets/images/service-page-1.jpg" style="width: 321.797px; height: 455.05px;"><b><span style="font-size: 48px;"><br></span></b></p><p style="text-align: center; "><br></p>', '', 1, '1', '2019-11-22', 'AIT', '2019-11-22', 'AIT'),
(15, 'Services 2', '<p style="text-align: center;"><span style="font-size: 48px;"><b>Services We Offer</b></span></p><p style="text-align: center;"><img src="http://192.168.1.244/aitadmin/assets/images/service-page-2.jpg" style="width: 325.297px; height: 460px;"><span style="font-weight: 600; text-align: center;"><span style="font-size: 48px;"><br></span></span></p><p style="text-align: justify; "><br></p>', '', 1, '1', '2019-11-22', 'AIT', '2019-11-22', 'AIT');

-- --------------------------------------------------------

--
-- Table structure for table `t`
--

CREATE TABLE `t` (
  `v` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t`
--

INSERT INTO `t` (`v`) VALUES
('A'),
('B'),
('C'),
('B');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_roles`
--
ALTER TABLE `admin_roles`
  ADD PRIMARY KEY (`iId`),
  ADD KEY `iId` (`iId`);

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`iId`),
  ADD KEY `iId` (`iId`);

--
-- Indexes for table `birthday`
--
ALTER TABLE `birthday`
  ADD PRIMARY KEY (`bdid`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`iId`),
  ADD KEY `iId` (`iId`);

--
-- Indexes for table `demo`
--
ALTER TABLE `demo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `masking`
--
ALTER TABLE `masking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slides`
--
ALTER TABLE `slides`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_roles`
--
ALTER TABLE `admin_roles`
  MODIFY `iId` mediumint(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `iId` mediumint(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `birthday`
--
ALTER TABLE `birthday`
  MODIFY `bdid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `iId` smallint(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `demo`
--
ALTER TABLE `demo`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=173;
--
-- AUTO_INCREMENT for table `masking`
--
ALTER TABLE `masking`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `slides`
--
ALTER TABLE `slides`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
